export type Severity = 'critical' | 'high' | 'medium' | 'low';
export type AlertStatus = 'action_required' | 'soc_investigating' | 'contained' | 'resolved' | 'false_positive';
export type EndpointOS = 'windows' | 'macos' | 'linux';
export type EndpointStatus = 'protected' | 'isolated' | 'warning' | 'offline';

export interface ProcessNode {
  id: string;
  name: string;
  pid: number;
  commandLine: string;
  user: string;
  isMalicious?: boolean;
  children?: ProcessNode[];
}

export interface NetworkConnection {
  protocol: 'TCP' | 'UDP';
  sourceIp: string;
  sourcePort: number;
  destinationIp: string;
  destinationPort: number;
  destinationCountry: string;
  reputation: 'malicious' | 'suspicious' | 'unknown' | 'benign';
}

export interface Alert {
  id: string;
  title: string;
  severity: Severity;
  status: AlertStatus;
  timestamp: string;
  endpointId: string;
  endpointName: string;
  endpointUser: string;
  endpointIp: string;
  os: EndpointOS;
  techniqueId: string;
  techniqueName: string;
  tactic: string;
  socSummary: string;
  businessRisk: string;
  socAnalyst: {
    name: string;
    role: string;
    avatar: string;
    notes: string;
    verifiedAt: string;
  };
  recommendedActions: string[];
  remediationStatus: {
    isolated: boolean;
    processKilled: boolean;
    snapshotReverted: boolean;
    iocBlocked: boolean;
  };
  processTree: ProcessNode;
  fileHash: {
    sha256: string;
    md5: string;
    fileName: string;
    filePath: string;
    vtDetections: string;
  };
  networkConnections: NetworkConnection[];
}

export interface Endpoint {
  id: string;
  hostname: string;
  user: string;
  department: string;
  os: EndpointOS;
  osVersion: string;
  ip: string;
  publicIp: string;
  agentVersion: string;
  agentMemoryMb: number;
  agentCpuPercent: number;
  status: EndpointStatus;
  lastHeartbeat: string;
  tamperProtection: boolean;
  activeAlertsCount: number;
  uptimeDays: number;
  assignedPolicy: string;
}

export interface ThreatFeedItem {
  id: string;
  ioc: string;
  type: 'sha256' | 'ip' | 'domain' | 'cve';
  source: 'CISA KEV' | 'AlienVault OTX' | 'SMB Ransomware Watch' | 'VirusTotal Intelligence';
  malwareFamily: string;
  severity: Severity;
  firstSeen: string;
  description: string;
  matchedEndpointsCount: number;
}

export interface CanaryTest {
  id: string;
  name: string;
  tactic: string;
  mitreRef: string;
  description: string;
  simulatedCommand: string;
  safePayloadDetails: string;
  expectedDetection: string;
}

export interface SocMessage {
  id: string;
  sender: 'soc_analyst' | 'user';
  senderName: string;
  timestamp: string;
  text: string;
  actionRecommendation?: string;
}
