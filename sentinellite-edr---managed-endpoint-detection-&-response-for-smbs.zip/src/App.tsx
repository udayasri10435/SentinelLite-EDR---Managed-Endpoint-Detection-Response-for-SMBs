import React, { useState } from 'react';
import {
  INITIAL_ALERTS,
  INITIAL_ENDPOINTS,
  THREAT_INTEL_FEED,
  CANARY_TESTS,
  INITIAL_SOC_MESSAGES,
} from './data/mockEdrData';
import { Alert, Endpoint, CanaryTest, SocMessage } from './types/edr';
import { Navbar } from './components/Navbar';
import { OverviewView } from './components/OverviewView';
import { AlertsView } from './components/AlertsView';
import { FleetView } from './components/FleetView';
import { ThreatIntelView } from './components/ThreatIntelView';
import { AttackSimulatorView } from './components/AttackSimulatorView';
import { CostCalculatorView } from './components/CostCalculatorView';
import { DeployAgentModal } from './components/DeployAgentModal';
import { SocAnalystModal } from './components/SocAnalystModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [alerts, setAlerts] = useState<Alert[]>(INITIAL_ALERTS);
  const [endpoints, setEndpoints] = useState<Endpoint[]>(INITIAL_ENDPOINTS);
  const [threatFeeds] = useState(THREAT_INTEL_FEED);
  const [canaryTests] = useState(CANARY_TESTS);
  const [socMessages, setSocMessages] = useState<SocMessage[]>(INITIAL_SOC_MESSAGES);
  const [selectedAlertId, setSelectedAlertId] = useState<string | null>(INITIAL_ALERTS[0]?.id || null);

  const [isDeployModalOpen, setIsDeployModalOpen] = useState<boolean>(false);
  const [isSocChatOpen, setIsSocChatOpen] = useState<boolean>(false);
  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification((curr) => (curr === msg ? null : curr));
    }, 3500);
  };

  const handleSelectAlert = (alertId: string) => {
    setSelectedAlertId(alertId);
    setActiveTab('alerts');
  };

  const handleUpdateAlertRemediation = (
    alertId: string,
    action: 'isolated' | 'processKilled' | 'snapshotReverted' | 'iocBlocked'
  ) => {
    setAlerts((prev) =>
      prev.map((alert) => {
        if (alert.id === alertId) {
          const updated = {
            ...alert,
            remediationStatus: {
              ...alert.remediationStatus,
              [action]: !alert.remediationStatus[action],
            },
          };

          // If action is isolated, sync endpoint
          if (action === 'isolated') {
            const willIsolate = !alert.remediationStatus.isolated;
            setEndpoints((prevEps) =>
              prevEps.map((ep) =>
                ep.id === alert.endpointId
                  ? { ...ep, status: willIsolate ? 'isolated' : 'protected' }
                  : ep
              )
            );
            if (willIsolate) {
              updated.status = 'contained';
              showNotification(`⚡ Endpoint ${alert.endpointName} isolated from LAN. SentinelLite agent tunnel preserved.`);
            } else {
              showNotification(`⚡ Network connectivity restored for ${alert.endpointName}.`);
            }
          }

          if (action === 'processKilled') {
            showNotification(`⚡ Malicious process tree terminated on ${alert.endpointName}.`);
          }
          if (action === 'snapshotReverted') {
            showNotification(`⚡ File rollback successful: Shadow snapshot restored to pre-execution state.`);
          }
          if (action === 'iocBlocked') {
            showNotification(`⚡ Threat IoC hash & IP broadcasted to all ${endpoints.length} fleet endpoints.`);
          }

          return updated;
        }
        return alert;
      })
    );
  };

  const handleToggleIsolation = (endpointId: string) => {
    setEndpoints((prev) =>
      prev.map((ep) => {
        if (ep.id === endpointId) {
          const isCurrentlyIsolated = ep.status === 'isolated';
          const newStatus = isCurrentlyIsolated ? 'protected' : 'isolated';
          showNotification(
            isCurrentlyIsolated
              ? `Reconnected ${ep.hostname} to corporate network.`
              : `⚡ Isolated ${ep.hostname} from local network segment.`
          );

          // Sync matching alerts
          setAlerts((prevAlerts) =>
            prevAlerts.map((a) =>
              a.endpointId === endpointId
                ? {
                    ...a,
                    status: newStatus === 'isolated' ? 'contained' : a.status,
                    remediationStatus: {
                      ...a.remediationStatus,
                      isolated: newStatus === 'isolated',
                    },
                  }
                : a
            )
          );

          return { ...ep, status: newStatus };
        }
        return ep;
      })
    );
  };

  const handleToggleTamperProtection = (endpointId: string) => {
    setEndpoints((prev) =>
      prev.map((ep) => {
        if (ep.id === endpointId) {
          const newVal = !ep.tamperProtection;
          showNotification(
            newVal
              ? `Tamper Protection enforced on ${ep.hostname}. Kernel hooks locked.`
              : `Tamper Protection disabled temporarily on ${ep.hostname}.`
          );
          return { ...ep, tamperProtection: newVal };
        }
        return ep;
      })
    );
  };

  const handleSimulateNewDevice = () => {
    const randomId = Math.floor(100 + Math.random() * 900);
    const newEndpoint: Endpoint = {
      id: `EP-WIN-${randomId}`,
      hostname: `SALES-LAPTOP-0${Math.floor(2 + Math.random() * 8)}`,
      user: 'k.novak',
      department: 'Field Sales',
      os: 'windows',
      osVersion: 'Windows 11 Pro 23H2',
      ip: `192.168.10.${Math.floor(120 + Math.random() * 80)}`,
      publicIp: '54.218.99.12',
      agentVersion: 'v2.8.4-ebpf',
      agentMemoryMb: 11.2,
      agentCpuPercent: 0.2,
      status: 'protected',
      lastHeartbeat: '1s ago',
      tamperProtection: true,
      activeAlertsCount: 0,
      uptimeDays: 1,
      assignedPolicy: 'Mobile Sales Remote Baseline',
    };

    setEndpoints((prev) => [newEndpoint, ...prev]);
    showNotification(`New lightweight agent enrolled: ${newEndpoint.hostname} (${newEndpoint.agentMemoryMb} MB RAM).`);
  };

  const handleExecuteCanaryTest = (test: CanaryTest, endpointId: string) => {
    const targetEndpoint = endpoints.find((e) => e.id === endpointId) || endpoints[0];
    const newAlertId = `ALT-CANARY-${Math.floor(1000 + Math.random() * 9000)}`;
    const nowTime = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';

    const newAlert: Alert = {
      id: newAlertId,
      title: `[Canary Test] ${test.name}`,
      severity: 'high',
      status: 'action_required',
      timestamp: nowTime,
      endpointId: targetEndpoint.id,
      endpointName: targetEndpoint.hostname,
      endpointUser: `${targetEndpoint.user} (Simulation)`,
      endpointIp: targetEndpoint.ip,
      os: targetEndpoint.os,
      techniqueId: test.mitreRef.split(' ')[2] || 'T1490',
      techniqueName: test.name,
      tactic: test.tactic,
      socSummary: `Canary simulation probe executed successfully. SentinelLite lightweight agent intercepted the command execution in memory within 0.4ms.`,
      businessRisk: `Verification test confirms that tamper protections and behavioral heuristics are operational on ${targetEndpoint.hostname}.`,
      socAnalyst: {
        name: 'Sarah Vance, GIAC GCDA',
        role: 'Lead Managed SOC Analyst',
        avatar: 'SV',
        notes: `Canary execution verified as a benign simulation token. Endpoint heuristics and kernel verifier reported zero delay in behavioral containment.`,
        verifiedAt: nowTime,
      },
      recommendedActions: [
        'Confirm detection signal in Managed Alert Triage.',
        'No actual endpoint remediation necessary (benign test flag).'
      ],
      remediationStatus: {
        isolated: false,
        processKilled: true,
        snapshotReverted: false,
        iocBlocked: false,
      },
      processTree: {
        id: 'p-canary-root',
        name: 'cmd.exe',
        pid: Math.floor(4000 + Math.random() * 3000),
        commandLine: test.simulatedCommand,
        user: targetEndpoint.user,
        isMalicious: true,
      },
      fileHash: {
        sha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
        md5: 'd41d8cd98f00b204e9800998ecf8427e',
        fileName: 'sentinel_canary_probe.tmp',
        filePath: 'C:\\Temp\\sentinel_canary_probe.tmp',
        vtDetections: 'Simulated Canary Token',
      },
      networkConnections: []
    };

    setAlerts((prev) => [newAlert, ...prev]);
    setSelectedAlertId(newAlertId);
    showNotification(`Canary Alert generated for ${targetEndpoint.hostname}! View in Managed Alerts.`);
  };

  const handleSendMessage = (text: string) => {
    const userMsg: SocMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      senderName: 'You (IT Administrator)',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text,
    };

    setSocMessages((prev) => [...prev, userMsg]);

    // Simulate Sarah Vance's response
    setTimeout(() => {
      let reply = 'Thank you for following up. We are actively monitoring your fleet and telemetry stream. All other workstations remain nominal.';
      let rec: string | undefined = undefined;

      const lower = text.toLowerCase();
      if (lower.includes('reconnect') || lower.includes('un-isolate')) {
        reply = 'Before reconnecting ACCT-WORKSTATION-01, our SOC recommends running a deep memory scan and confirming that the macro temp files in C:\\Users\\d.clarkson\\AppData\\Local\\Temp have been purged.';
        rec = 'Revert File Modifications';
      } else if (lower.includes('insurance') || lower.includes('report')) {
        reply = 'We have generated an Incident Triage Pack containing the cryptographic hash chain, MITRE mapping, and proof of non-encryption for your cyber insurance underwriter.';
      } else if (lower.includes('credential') || lower.includes('leak')) {
        reply = 'Our kernel eBPF driver confirmed that LSASS was not touched and no unauthorized handles were created. Credentials remain secure.';
      } else if (lower.includes('block') || lower.includes('ioc')) {
        reply = 'IoC pushed to all endpoints. Outbound connection attempts to 185.220.101.44 will be dropped at the host level.';
        rec = 'Execute Fleet-wide IoC Block';
      }

      const socReply: SocMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'soc_analyst',
        senderName: 'Sarah Vance, GIAC GCDA (Lead SOC Analyst)',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        text: reply,
        actionRecommendation: rec,
      };

      setSocMessages((prev) => [...prev, socReply]);
    }, 600);
  };

  const handleExecuteRecommendation = (actionText: string) => {
    if (actionText.includes('Isolate')) {
      handleToggleIsolation('EP-WIN-003');
    } else if (actionText.includes('IoC Block')) {
      handleUpdateAlertRemediation('ALT-8821', 'iocBlocked');
    } else if (actionText.includes('Revert')) {
      handleUpdateAlertRemediation('ALT-8821', 'snapshotReverted');
    }
  };

  const activeAlertsCount = alerts.filter(
    (a) => a.status === 'action_required' || a.status === 'soc_investigating'
  ).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar Contract compliant Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        openDeployModal={() => setIsDeployModalOpen(true)}
        openSocChat={() => setIsSocChatOpen(true)}
        activeAlertsCount={activeAlertsCount}
      />

      {/* Ephemeral Toast Notification */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-xl border border-cyan-500/40 bg-slate-900/95 px-4 py-3 text-xs font-medium text-cyan-200 shadow-2xl backdrop-blur-md transition-all animate-in fade-in slide-in-from-bottom-4">
          <div className="h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
          <span>{notification}</span>
        </div>
      )}

      {/* Main Viewport Container */}
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'overview' && (
          <OverviewView
            alerts={alerts}
            endpoints={endpoints}
            onSelectAlert={handleSelectAlert}
            onNavigateTab={setActiveTab}
            onIsolateEndpoint={handleToggleIsolation}
          />
        )}

        {activeTab === 'alerts' && (
          <AlertsView
            alerts={alerts}
            selectedAlertId={selectedAlertId}
            onSelectAlert={setSelectedAlertId}
            onUpdateAlertRemediation={handleUpdateAlertRemediation}
            onOpenSocChat={() => setIsSocChatOpen(true)}
          />
        )}

        {activeTab === 'fleet' && (
          <FleetView
            endpoints={endpoints}
            onToggleIsolation={handleToggleIsolation}
            onToggleTamperProtection={handleToggleTamperProtection}
            onOpenDeployModal={() => setIsDeployModalOpen(true)}
            onSimulateNewDevice={handleSimulateNewDevice}
          />
        )}

        {activeTab === 'threat-intel' && (
          <ThreatIntelView
            threatFeeds={threatFeeds}
            endpoints={endpoints}
            onOpenSocChat={() => setIsSocChatOpen(true)}
          />
        )}

        {activeTab === 'canary' && (
          <AttackSimulatorView
            canaryTests={canaryTests}
            endpoints={endpoints}
            onExecuteCanaryTest={handleExecuteCanaryTest}
            onNavigateToAlerts={() => setActiveTab('alerts')}
          />
        )}

        {activeTab === 'tco' && (
          <CostCalculatorView
            onOpenDeployModal={() => setIsDeployModalOpen(true)}
            onOpenSocChat={() => setIsSocChatOpen(true)}
          />
        )}
      </main>

      {/* Modals & Drawers */}
      <DeployAgentModal
        isOpen={isDeployModalOpen}
        onClose={() => setIsDeployModalOpen(false)}
      />

      <SocAnalystModal
        isOpen={isSocChatOpen}
        onClose={() => setIsSocChatOpen(false)}
        messages={socMessages}
        onSendMessage={handleSendMessage}
        onExecuteRecommendation={handleExecuteRecommendation}
      />

      {/* Quiet Corporate Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-6 text-xs text-slate-500">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">SentinelLite EDR</span>
            <span aria-hidden="true">·</span>
            <span>Managed Endpoint Security for Small & Midsize Business</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono">eBPF Kernel v2.8.4</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <button onClick={() => setActiveTab('tco')} className="hover:text-white transition-colors">
              Pricing & TCO
            </button>
            <button onClick={() => setIsDeployModalOpen(true)} className="hover:text-white transition-colors">
              Download Agent
            </button>
            <button onClick={() => setIsSocChatOpen(true)} className="hover:text-white transition-colors">
              SOC Escalation Hotline
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
