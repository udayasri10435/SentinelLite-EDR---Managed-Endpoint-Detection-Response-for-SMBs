import React from 'react';
import { Shield, MessageSquare, Plus } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  openDeployModal: () => void;
  openSocChat: () => void;
  activeAlertsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  openDeployModal,
  openSocChat,
  activeAlertsCount,
}) => {
  const navItems = [
    { id: 'overview', label: 'Overview' },
    { id: 'alerts', label: 'Managed Alerts', badge: activeAlertsCount },
    { id: 'fleet', label: 'Fleet & Agents' },
    { id: 'threat-intel', label: 'Threat Intel' },
    { id: 'canary', label: 'Attack Simulator' },
    { id: 'tco', label: 'Cost Calculator' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-2">
          <a
            href="#overview"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('overview');
            }}
            className="flex items-center gap-2.5 text-base font-bold tracking-tight text-white transition-opacity hover:opacity-90"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Shield className="h-4 w-4" />
            </div>
            <span>SentinelLite EDR</span>
          </a>
        </div>

        {/* Zone 2: Clean text navigation links */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-2">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`relative px-3 py-1.5 text-xs lg:text-sm font-medium transition-colors whitespace-nowrap rounded-md ${
                  isActive
                    ? 'text-cyan-400 bg-cyan-950/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <span>{item.label}</span>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="ml-1.5 font-mono text-xs text-rose-400">
                    ({item.badge})
                  </span>
                )}
                {isActive && (
                  <span className="absolute bottom-0 left-3 right-3 h-0.5 bg-cyan-400 rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={openSocChat}
            className="flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-900/80 px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-slate-600 hover:bg-slate-800 transition-colors whitespace-nowrap"
            title="Speak directly with on-duty 24/7 SOC Analyst"
          >
            <div className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            <MessageSquare className="h-3.5 w-3.5 text-slate-400" />
            <span className="hidden sm:inline">24/7 Managed SOC</span>
          </button>

          <button
            onClick={openDeployModal}
            className="flex items-center gap-1.5 rounded-lg bg-cyan-500 px-3.5 py-1.5 text-xs font-semibold text-slate-950 hover:bg-cyan-400 transition-colors whitespace-nowrap shadow-sm shadow-cyan-500/20"
          >
            <Plus className="h-3.5 w-3.5 stroke-[2.5]" />
            <span>Deploy Agent</span>
          </button>
        </div>
      </div>

      {/* Mobile nav bar row for small screens */}
      <div className="flex md:hidden overflow-x-auto border-t border-slate-800/80 px-4 py-2 gap-2 text-xs scrollbar-none">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`px-2.5 py-1 rounded whitespace-nowrap font-medium ${
              activeTab === item.id
                ? 'bg-cyan-500/20 text-cyan-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {item.label}
            {item.badge !== undefined && item.badge > 0 && (
              <span className="ml-1 text-rose-400 font-mono">({item.badge})</span>
            )}
          </button>
        ))}
      </div>
    </header>
  );
};
