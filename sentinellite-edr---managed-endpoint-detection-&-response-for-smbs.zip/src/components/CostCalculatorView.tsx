import React, { useState } from 'react';
import {
  DollarSign,
  TrendingDown,
  CheckCircle2,
  XCircle,
  Clock,
  Shield,
  ArrowRight,
  Sliders
} from 'lucide-react';

interface CostCalculatorViewProps {
  onOpenDeployModal: () => void;
  onOpenSocChat: () => void;
}

export const CostCalculatorView: React.FC<CostCalculatorViewProps> = ({
  onOpenDeployModal,
  onOpenSocChat,
}) => {
  const [endpointCount, setEndpointCount] = useState<number>(35);

  // Financial calculations
  const enterpriseLicensePerYear = endpointCount * 140; // $140/endpoint/yr
  const enterpriseMsspSocCost = 48000; // $4,000/mo MSSP minimum retainer
  const enterpriseSetupFee = 4500;
  const enterpriseTotalAnnual = enterpriseLicensePerYear + enterpriseMsspSocCost + enterpriseSetupFee;

  const sentinelLiteAnnual = endpointCount * 48; // $4/mo = $48/yr including 24/7 Managed SOC
  const sentinelLiteSetupFee = 0;
  const sentinelLiteTotalAnnual = sentinelLiteAnnual + sentinelLiteSetupFee;

  const annualSavings = enterpriseTotalAnnual - sentinelLiteTotalAnnual;
  const percentSaved = Math.round((annualSavings / enterpriseTotalAnnual) * 100);
  const itHoursSavedPerYear = Math.round(endpointCount * 8.5);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            SMB Cost & TCO Savings Calculator
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Compare real costs: Enterprise EDR + external MSSP retainers vs. SentinelLite’s all-inclusive model.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenDeployModal}
            className="rounded-lg bg-cyan-500 px-4 py-1.5 text-xs font-semibold text-slate-950 hover:bg-cyan-400 transition-colors shadow-sm"
          >
            Start Free 30-Day Fleet Trial
          </button>
        </div>
      </div>

      {/* Interactive Slider & Result Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* Slider Controls (5 cols) */}
        <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-6">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Number of Fleet Endpoints
              </span>
              <span className="font-mono text-2xl font-bold text-cyan-400 tabular-nums">
                {endpointCount}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Workstations, executive laptops, and internal servers
            </p>
          </div>

          <div className="space-y-2">
            <input
              type="range"
              min="10"
              max="250"
              step="5"
              value={endpointCount}
              onChange={(e) => setEndpointCount(Number(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer h-2 bg-slate-800 rounded-lg"
            />
            <div className="flex justify-between text-[11px] font-mono text-slate-500">
              <span>10 endpoints</span>
              <span>50</span>
              <span>100</span>
              <span>175</span>
              <span>250 endpoints</span>
            </div>
          </div>

          {/* Quick preset buttons */}
          <div className="pt-2 border-t border-slate-800/80">
            <div className="text-[11px] text-slate-400 mb-2">Popular SMB sizes:</div>
            <div className="flex flex-wrap gap-2">
              {[15, 35, 75, 120, 200].map((num) => (
                <button
                  key={num}
                  onClick={() => setEndpointCount(num)}
                  className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
                    endpointCount === num
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {num} devices
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Savings Big Metric Card (7 cols) */}
        <div className="lg:col-span-7 rounded-xl border border-emerald-500/30 bg-emerald-950/10 p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-emerald-900/40 pb-4">
            <div>
              <div className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
                Projected Annual Savings
              </div>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="font-mono text-4xl sm:text-5xl font-extrabold text-white tabular-nums">
                  ${annualSavings.toLocaleString()}
                </span>
                <span className="text-sm font-semibold text-emerald-400">
                  ({percentSaved}% lower annual cost)
                </span>
              </div>
            </div>

            <div className="rounded-lg bg-emerald-500/10 border border-emerald-500/30 px-3 py-2 text-right">
              <div className="text-[11px] text-slate-300">Admin Hours Saved</div>
              <div className="font-mono text-lg font-bold text-white tabular-nums">
                ~{itHoursSavedPerYear} hrs / yr
              </div>
            </div>
          </div>

          {/* Side by Side Cost Breakdown */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            {/* Enterprise Cost Box */}
            <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-4 space-y-2">
              <div className="font-semibold text-rose-400 flex items-center justify-between">
                <span>Enterprise EDR + MSSP</span>
                <span className="font-mono tabular-nums">${enterpriseTotalAnnual.toLocaleString()}/yr</span>
              </div>
              <div className="space-y-1.5 text-slate-400 text-[11px] pt-1">
                <div className="flex justify-between">
                  <span>EDR Licenses (${140} × {endpointCount}):</span>
                  <span className="font-mono text-slate-300">${enterpriseLicensePerYear.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Mandatory MSSP SOC Retainer:</span>
                  <span className="font-mono text-slate-300">$48,000</span>
                </div>
                <div className="flex justify-between">
                  <span>Professional Setup & Tuning:</span>
                  <span className="font-mono text-slate-300">$4,500</span>
                </div>
              </div>
            </div>

            {/* SentinelLite Cost Box */}
            <div className="rounded-lg border border-cyan-500/40 bg-cyan-950/20 p-4 space-y-2">
              <div className="font-semibold text-cyan-300 flex items-center justify-between">
                <span>SentinelLite EDR + SOC</span>
                <span className="font-mono tabular-nums">${sentinelLiteTotalAnnual.toLocaleString()}/yr</span>
              </div>
              <div className="space-y-1.5 text-slate-300 text-[11px] pt-1">
                <div className="flex justify-between">
                  <span>All-Inclusive ($4/mo × {endpointCount}):</span>
                  <span className="font-mono text-white font-semibold">${sentinelLiteAnnual.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>24/7 Managed SOC Triage:</span>
                  <span className="font-mono text-emerald-400 font-semibold">$0 (Included)</span>
                </div>
                <div className="flex justify-between">
                  <span>Setup / Onboarding Fee:</span>
                  <span className="font-mono text-emerald-400 font-semibold">$0 (Free)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Feature & Architecture Comparison Matrix */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-6">
        <h2 className="text-base font-semibold text-white mb-1">
          Detailed Capability Comparison: Enterprise EDR vs. SentinelLite
        </h2>
        <p className="text-xs text-slate-400 mb-4">
          Why enterprise tools burden lean SMB IT teams with unnecessary bloat and overhead
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="pb-3 font-medium">Evaluation Criterion</th>
                <th className="pb-3 font-medium text-rose-400">Traditional Enterprise EDR</th>
                <th className="pb-3 font-medium text-cyan-300">SentinelLite EDR for SMBs</th>
                <th className="pb-3 font-medium text-right">SMB Impact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-3 font-medium text-white">Agent Memory Consumption</td>
                <td className="py-3 text-rose-400">450MB – 850MB RAM per host</td>
                <td className="py-3 text-emerald-400 font-semibold">&lt;15MB RAM (Rust / eBPF)</td>
                <td className="py-3 text-right text-slate-400">Zero slowdown on older hardware</td>
              </tr>
              <tr>
                <td className="py-3 font-medium text-white">Kernel Stability & Reboots</td>
                <td className="py-3 text-rose-400">Invasive kernel hooks; reboots required</td>
                <td className="py-3 text-emerald-400 font-semibold">Zero reboots; safe eBPF verifier</td>
                <td className="py-3 text-right text-slate-400">No blue screens or business outages</td>
              </tr>
              <tr>
                <td className="py-3 font-medium text-white">24/7 Human SOC Triage</td>
                <td className="py-3 text-rose-400">Separate $40k–$80k MSSP contract</td>
                <td className="py-3 text-emerald-400 font-semibold">Included in base $4/mo rate</td>
                <td className="py-3 text-right text-slate-400">Affordable for 10-person offices</td>
              </tr>
              <tr>
                <td className="py-3 font-medium text-white">Alert Presentation</td>
                <td className="py-3 text-rose-400">Raw JSON telemetry (80+ alerts/day)</td>
                <td className="py-3 text-emerald-400 font-semibold">Plain-English risk + 1-click fix</td>
                <td className="py-3 text-right text-slate-400">Solves IT admin burnout</td>
              </tr>
              <tr>
                <td className="py-3 font-medium text-white">Deployment Speed</td>
                <td className="py-3 text-rose-400">2–4 weeks policy tuning consultant</td>
                <td className="py-3 text-emerald-400 font-semibold">5-minute 1-command install</td>
                <td className="py-3 text-right text-slate-400">Instant protection same-day</td>
              </tr>
              <tr>
                <td className="py-3 font-medium text-white">Contract Minimums</td>
                <td className="py-3 text-rose-400">100–250 seat mandatory minimums</td>
                <td className="py-3 text-emerald-400 font-semibold">No seat minimums (starts at 5)</td>
                <td className="py-3 text-right text-slate-400">Pay only for what you run</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
