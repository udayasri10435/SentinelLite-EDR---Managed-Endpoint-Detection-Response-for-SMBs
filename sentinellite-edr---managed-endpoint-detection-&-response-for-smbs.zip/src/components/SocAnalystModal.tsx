import React, { useState } from 'react';
import { SocMessage } from '../types/edr';
import {
  X,
  Send,
  Shield,
  MessageSquare,
  Sparkles,
  CheckCircle2,
  Lock,
  PhoneCall,
  User
} from 'lucide-react';

interface SocAnalystModalProps {
  isOpen: boolean;
  onClose: () => void;
  messages: SocMessage[];
  onSendMessage: (text: string) => void;
  onExecuteRecommendation?: (actionText: string) => void;
}

export const SocAnalystModal: React.FC<SocAnalystModalProps> = ({
  isOpen,
  onClose,
  messages,
  onSendMessage,
  onExecuteRecommendation,
}) => {
  const [inputText, setInputText] = useState('');

  if (!isOpen) return null;

  const handleSend = () => {
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const quickQuestions = [
    'Is it safe to reconnect ACCT-WORKSTATION-01?',
    'Can you generate an executive summary report for cyber insurance?',
    'Did any credentials leak from memory during the vssadmin probe?',
    'Please push an IoC block for the Tor exit node.'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-sm">
      <div className="relative flex h-full w-full max-w-xl flex-col border-l border-slate-800 bg-slate-900 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 p-4 bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40 text-sm">
                SV
              </div>
              <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-emerald-500 ring-2 ring-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-white">Sarah Vance, GIAC GCDA</h2>
                <span className="rounded bg-cyan-950/60 border border-cyan-800/40 px-1.5 py-0.2 text-[10px] text-cyan-300 font-medium">
                  Lead SOC Analyst
                </span>
              </div>
              <div className="text-xs text-slate-400">
                SentinelLite 24/7 Managed Detection Unit · Shift #3
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* SLA Status Bar */}
        <div className="bg-emerald-950/20 border-b border-emerald-900/30 px-4 py-2 flex items-center justify-between text-xs text-emerald-300">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span>Live Analyst On Duty · Triage SLA: 4.2 min</span>
          </div>
          <span className="text-slate-400 text-[11px]">Included with SentinelLite SMB</span>
        </div>

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => {
            const isSoc = msg.sender === 'soc_analyst';
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isSoc ? 'items-start' : 'items-end'}`}
              >
                <div className="flex items-center gap-2 mb-1 text-[11px] text-slate-400">
                  <span className="font-semibold text-slate-300">{msg.senderName}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{msg.timestamp}</span>
                </div>

                <div
                  className={`max-w-[88%] rounded-2xl p-3.5 text-xs leading-relaxed ${
                    isSoc
                      ? 'bg-slate-950 border border-slate-800 text-slate-200'
                      : 'bg-cyan-600 text-white'
                  }`}
                >
                  <p>{msg.text}</p>

                  {msg.actionRecommendation && (
                    <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between gap-2">
                      <span className="text-[11px] text-cyan-300 font-medium">
                        Suggested Action:
                      </span>
                      <button
                        onClick={() =>
                          onExecuteRecommendation &&
                          onExecuteRecommendation(msg.actionRecommendation!)
                        }
                        className="rounded bg-cyan-500/20 border border-cyan-500/40 px-2.5 py-1 text-[11px] font-semibold text-cyan-200 hover:bg-cyan-500/30 transition-colors"
                      >
                        ⚡ {msg.actionRecommendation}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Quick Suggestion Chips */}
        <div className="border-t border-slate-800/80 px-4 py-2 bg-slate-950/40">
          <div className="text-[11px] text-slate-500 mb-1.5">Common SMB incident inquiries:</div>
          <div className="flex flex-wrap gap-1.5">
            {quickQuestions.map((q, idx) => (
              <button
                key={idx}
                onClick={() => setInputText(q)}
                className="rounded-md border border-slate-800 bg-slate-900 px-2 py-1 text-[11px] text-slate-300 hover:border-slate-700 hover:text-white transition-colors"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Input Footer */}
        <div className="border-t border-slate-800 p-4 bg-slate-950">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask Sarah or your SOC team a question..."
              className="flex-1 rounded-xl border border-slate-800 bg-slate-900 px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
            />
            <button
              type="submit"
              disabled={!inputText.trim()}
              className="flex h-9 w-9 items-center justify-center rounded-xl bg-cyan-500 text-slate-950 hover:bg-cyan-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shrink-0"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
          <div className="mt-2 text-center text-[10px] text-slate-500">
            Emergency hotline backup: +1 (800) 555-AEGIS-EDR · Direct SOC triage console
          </div>
        </div>
      </div>
    </div>
  );
};
