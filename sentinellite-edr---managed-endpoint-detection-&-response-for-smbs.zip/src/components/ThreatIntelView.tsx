import React, { useState } from 'react';
import { ThreatFeedItem, Endpoint } from '../types/edr';
import {
  Globe,
  Search,
  ShieldAlert,
  AlertTriangle,
  ExternalLink,
  CheckCircle2,
  FileText,
  Lock,
  ArrowRight,
  Database
} from 'lucide-react';

interface ThreatIntelViewProps {
  threatFeeds: ThreatFeedItem[];
  endpoints: Endpoint[];
  onOpenSocChat: () => void;
}

export const ThreatIntelView: React.FC<ThreatIntelViewProps> = ({
  threatFeeds,
  endpoints,
  onOpenSocChat,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [scanResult, setScanResult] = useState<{
    query: string;
    matched: boolean;
    endpoints: string[];
    details: string;
  } | null>(null);

  const filteredFeeds = threatFeeds.filter((item) => {
    if (filterType !== 'all' && item.type !== filterType) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        item.ioc.toLowerCase().includes(q) ||
        item.malwareFamily.toLowerCase().includes(q) ||
        item.source.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const handleFleetScan = (iocQuery: string) => {
    const q = iocQuery.trim();
    if (!q) return;

    if (q.includes('185.220.101.44') || q.includes('9a3f81e7d80c32b509f6e2dc08ef128a3f9901b04b90ec22a10dfa48c903a451')) {
      setScanResult({
        query: q,
        matched: true,
        endpoints: ['ACCT-WORKSTATION-01'],
        details: 'MATCH DETECTED: Endpoint ACCT-WORKSTATION-01 initiated network telemetry to this indicator within the last 2 hours. Process suspended by SentinelLite.',
      });
    } else if (q.includes('cdn-updates-win.online') || q.includes('41efc88219199a0bba8120c909ee8834920a112df88491cba908754123561a0f')) {
      setScanResult({
        query: q,
        matched: true,
        endpoints: ['OFFICE-FILESRV-01'],
        details: 'MATCH DETECTED: certutil.exe download probe reached this indicator on OFFICE-FILESRV-01. File write blocked by eBPF driver.',
      });
    } else if (q.toLowerCase().includes('cve-2024-1709')) {
      setScanResult({
        query: q,
        matched: false,
        endpoints: [],
        details: 'ZERO EXPOSURE: All SMB fleet endpoints have ScreenConnect versions >= 23.9.8 or service disabled. No vulnerable ports exposed.',
      });
    } else {
      setScanResult({
        query: q,
        matched: false,
        endpoints: [],
        details: `ZERO EXPOSURE: Scanned ${endpoints.length} active fleet endpoints across 90 days of kernel telemetry. No matches found for indicator "${q}".`,
      });
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            SMB Threat Intelligence & Indicator Search
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Continuously synced with CISA KEV, AlienVault OTX, and ransomware trackers tailored for small business threat surfaces.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSocChat}
            className="flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-900 px-3.5 py-1.5 text-xs font-medium text-slate-200 hover:border-slate-600 hover:bg-slate-800 transition-colors"
          >
            <span>Request Custom IoC Sweep</span>
          </button>
        </div>
      </div>

      {/* Interactive IoC Fleet Scanner */}
      <div className="rounded-xl border border-cyan-500/30 bg-slate-900/60 p-5 space-y-4">
        <div>
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <Database className="h-4 w-4 text-cyan-400" />
            <span>Instant Fleet-Wide IoC Retrospective Sweep</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Search any suspicious IP, domain, hash, or CVE across all telemetry logs recorded by your lightweight agents.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleFleetScan(searchQuery);
              }}
              placeholder="e.g. 185.220.101.44 or CVE-2024-1709 or SHA-256 hash..."
              className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 pl-9 py-2 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
            />
          </div>
          <button
            onClick={() => handleFleetScan(searchQuery || '185.220.101.44')}
            className="rounded-lg bg-cyan-500 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-cyan-400 transition-colors whitespace-nowrap"
          >
            Scan Fleet Telemetry
          </button>
        </div>

        {/* Quick Suggestion Chips (Buttons) */}
        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
          <span className="text-[11px] text-slate-500">Quick scan tests:</span>
          {[
            { label: 'C2 IP (LockBit)', val: '185.220.101.44' },
            { label: 'ScreenConnect CVE', val: 'CVE-2024-1709' },
            { label: 'DarkGate Trojan Hash', val: '9a3f81e7d80c32b509f6e2dc08ef128a3f9901b04b90ec22a10dfa48c903a451' },
            { label: 'Safe Internal Host', val: '192.168.10.1' },
          ].map((s) => (
            <button
              key={s.val}
              onClick={() => {
                setSearchQuery(s.val);
                handleFleetScan(s.val);
              }}
              className="rounded bg-slate-800/80 px-2 py-0.5 text-[11px] text-slate-300 hover:bg-slate-700 hover:text-white transition-colors"
            >
              {s.label}
            </button>
          ))}
        </div>

        {/* Scan Results Display */}
        {scanResult && (
          <div
            className={`rounded-lg border p-3.5 text-xs transition-all ${
              scanResult.matched
                ? 'border-rose-500/40 bg-rose-950/20 text-rose-200'
                : 'border-emerald-500/40 bg-emerald-950/20 text-emerald-200'
            }`}
          >
            <div className="flex items-center gap-2 font-semibold">
              {scanResult.matched ? (
                <>
                  <AlertTriangle className="h-4 w-4 text-rose-400 shrink-0" />
                  <span className="text-rose-300">IoC Encounter Detected in Fleet Telemetry</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span className="text-emerald-300">Zero Fleet Exposure Confirmed</span>
                </>
              )}
            </div>
            <p className="mt-1 text-xs text-slate-300 leading-relaxed">
              {scanResult.details}
            </p>
            {scanResult.matched && scanResult.endpoints.length > 0 && (
              <div className="mt-2 pt-2 border-t border-rose-900/40 flex items-center justify-between text-xs">
                <span>Affected Hosts: <strong className="text-white">{scanResult.endpoints.join(', ')}</strong></span>
                <span className="text-rose-400 font-semibold underline cursor-pointer">
                  Go to Alert Triage →
                </span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Real-Time SMB Threat Intel Feed */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-white">Live Threat Intelligence Stream</h2>
            <p className="text-xs text-slate-400">Indicators actively queried by lightweight agents during behavioral analysis</p>
          </div>

          {/* Type Filter Buttons */}
          <div className="flex items-center rounded-lg border border-slate-800 bg-slate-900/80 p-0.5 text-xs">
            {['all', 'ip', 'sha256', 'domain', 'cve'].map((t) => (
              <button
                key={t}
                onClick={() => setFilterType(t)}
                className={`px-2.5 py-1 rounded uppercase font-medium transition-colors ${
                  filterType === t
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="pb-3 font-medium">Indicator / IoC</th>
                <th className="pb-3 font-medium">Type</th>
                <th className="pb-3 font-medium">Malware Family</th>
                <th className="pb-3 font-medium">Threat Source</th>
                <th className="pb-3 font-medium text-right">Fleet Hits</th>
                <th className="pb-3 font-medium text-right">Severity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredFeeds.map((feed) => (
                <tr key={feed.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-3 pr-4">
                    <div className="font-mono text-cyan-300 font-medium break-all">{feed.ioc}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">{feed.description}</div>
                  </td>
                  <td className="py-3 text-slate-300 uppercase font-mono text-[11px]">{feed.type}</td>
                  <td className="py-3 text-slate-200 font-medium">{feed.malwareFamily}</td>
                  <td className="py-3 text-slate-400">{feed.source}</td>
                  <td className="py-3 text-right">
                    {feed.matchedEndpointsCount > 0 ? (
                      <span className="font-mono font-semibold text-rose-400 tabular-nums">
                        {feed.matchedEndpointsCount} match
                      </span>
                    ) : (
                      <span className="font-mono text-slate-500 tabular-nums">0 hits</span>
                    )}
                  </td>
                  <td className="py-3 text-right">
                    <span
                      className={`font-semibold uppercase ${
                        feed.severity === 'critical'
                          ? 'text-rose-400'
                          : feed.severity === 'high'
                          ? 'text-amber-400'
                          : 'text-cyan-400'
                      }`}
                    >
                      {feed.severity}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* SMB Threat Advisories & Prevention Playbooks */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/30 p-5">
        <h2 className="text-base font-semibold text-white mb-1">
          Targeted SMB Threat Advisories & Playbooks
        </h2>
        <p className="text-xs text-slate-400 mb-4">
          Curated guidance from our Managed SOC for small business IT admins
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-4 space-y-2">
            <div className="text-xs font-bold text-amber-400">
              01. ScreenConnect Remote Exploits
            </div>
            <p className="text-slate-300 leading-relaxed">
              Attackers continue mass-scanning SMB IT service desks. SentinelLite automatically monitors local setup wizard ports and isolates any rogue accounts created outside Active Directory.
            </p>
            <div className="pt-2 text-[11px] text-cyan-400 font-medium">
              Recommendation: Upgrade to v23.9.8+ or enable SentinelLite auto-quarantine.
            </div>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-4 space-y-2">
            <div className="text-xs font-bold text-rose-400">
              02. Fake Invoice ZIPs & Malicious Macros
            </div>
            <p className="text-slate-300 leading-relaxed">
              Accounting teams are the primary target for initial access loaders. Our agent monitors Office binary child-process creation, killing cmd.exe or powershell.exe when spawned by Excel.
            </p>
            <div className="pt-2 text-[11px] text-cyan-400 font-medium">
              Recommendation: Keep Office Child Process Blocking policy enforced.
            </div>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-4 space-y-2">
            <div className="text-xs font-bold text-cyan-400">
              03. RDP Brute Force & Credential Spraying
            </div>
            <p className="text-slate-300 leading-relaxed">
              Exposed port 3389 accounts for 42% of SMB ransomware breaches. SentinelLite detects rapid authentication failures and automatically blacklists the attacking external IP.
            </p>
            <div className="pt-2 text-[11px] text-cyan-400 font-medium">
              Recommendation: Mandate WireGuard/Tailscale VPN before RDP access.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
