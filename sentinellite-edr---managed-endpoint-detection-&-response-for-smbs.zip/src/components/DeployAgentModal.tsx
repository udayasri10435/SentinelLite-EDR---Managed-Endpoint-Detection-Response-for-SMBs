import React, { useState } from 'react';
import { X, Copy, Check, Terminal, Shield, Download, CheckCircle2 } from 'lucide-react';

interface DeployAgentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DeployAgentModal: React.FC<DeployAgentModalProps> = ({ isOpen, onClose }) => {
  const [activePlatform, setActivePlatform] = useState<'windows' | 'macos' | 'linux'>('windows');
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const scripts = {
    windows: `# Run in Administrator PowerShell:
Set-ExecutionPolicy Bypass -Scope Process -Force;
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072;
iex ((New-Object System.Net.WebClient).DownloadString('https://dl.sentinellite.security/install.ps1')) -Token "stl_smb_8821_aegis" -TenantId "org_smb_7710";`,
    macos: `# Run in macOS Terminal (or distribute via Jamf / Kandji):
curl -sSL https://dl.sentinellite.security/mac-install.sh | sudo bash -s -- --token "stl_smb_8821_aegis" --tenant "org_smb_7710"`,
    linux: `# Run on Debian/Ubuntu/RHEL/CentOS (Kernel >= 5.8 eBPF):
curl -fsSL https://dl.sentinellite.security/linux-ebpf-install.sh | sudo bash -s -- --token "stl_smb_8821_aegis" --tenant "org_smb_7710"`
  };

  const currentScript = scripts[activePlatform];

  const handleCopy = () => {
    navigator.clipboard.writeText(currentScript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-2xl rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Shield className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Deploy SentinelLite Lightweight Agent</h2>
              <p className="text-xs text-slate-400">Zero reboots, &lt;15MB RAM footprint, silent enrollment</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Platform Selector Tabs */}
        <div className="flex items-center rounded-lg border border-slate-800 bg-slate-950 p-1 text-xs">
          {[
            { id: 'windows', label: 'Windows (MSI / PowerShell / Intune)' },
            { id: 'macos', label: 'macOS (PKG / Jamf / Terminal)' },
            { id: 'linux', label: 'Linux (Debian / Ubuntu / RHEL eBPF)' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActivePlatform(item.id as any);
                setCopied(false);
              }}
              className={`flex-1 py-1.5 px-3 rounded-md font-medium text-center transition-all ${
                activePlatform === item.id
                  ? 'bg-cyan-500/20 text-cyan-300 shadow-sm border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Script Box */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1.5">
              <Terminal className="h-3.5 w-3.5 text-cyan-400" />
              <span>1-Command Silent Installation Script:</span>
            </span>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-medium"
            >
              {copied ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied to Clipboard!</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy Command</span>
                </>
              )}
            </button>
          </div>

          <div className="relative rounded-xl border border-slate-800 bg-slate-950 p-4 font-mono text-xs text-slate-200 break-all leading-relaxed">
            {currentScript}
          </div>
        </div>

        {/* Specifications & Guarantees */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="rounded-lg border border-slate-800/80 bg-slate-950/60 p-2.5">
            <div className="text-slate-500 text-[11px]">RAM Footprint</div>
            <div className="font-mono text-white font-semibold tabular-nums mt-0.5">&lt; 15 MB avg</div>
          </div>
          <div className="rounded-lg border border-slate-800/80 bg-slate-950/60 p-2.5">
            <div className="text-slate-500 text-[11px]">Reboot Needed</div>
            <div className="font-mono text-emerald-400 font-semibold mt-0.5">0 (None)</div>
          </div>
          <div className="rounded-lg border border-slate-800/80 bg-slate-950/60 p-2.5">
            <div className="text-slate-500 text-[11px]">Bandwidth</div>
            <div className="font-mono text-white font-semibold tabular-nums mt-0.5">~12 KB / hr</div>
          </div>
          <div className="rounded-lg border border-slate-800/80 bg-slate-950/60 p-2.5">
            <div className="text-slate-500 text-[11px]">Offline Buffer</div>
            <div className="font-mono text-cyan-300 font-semibold tabular-nums mt-0.5">14 Days</div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs text-slate-400">
          <span>Tenant Organization: <strong className="text-white font-mono">org_smb_7710</strong></span>
          <button
            onClick={onClose}
            className="rounded-lg bg-slate-800 px-4 py-2 font-medium text-white hover:bg-slate-700 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
