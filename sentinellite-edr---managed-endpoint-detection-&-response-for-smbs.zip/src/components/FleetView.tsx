import React, { useState } from 'react';
import { Endpoint, EndpointOS } from '../types/edr';
import {
  Server,
  Laptop,
  Search,
  Plus,
  Shield,
  ShieldAlert,
  Lock,
  Unlock,
  CheckCircle2,
  RefreshCw,
  Cpu,
  Layers,
  Sparkles
} from 'lucide-react';

interface FleetViewProps {
  endpoints: Endpoint[];
  onToggleIsolation: (endpointId: string) => void;
  onToggleTamperProtection: (endpointId: string) => void;
  onOpenDeployModal: () => void;
  onSimulateNewDevice: () => void;
}

export const FleetView: React.FC<FleetViewProps> = ({
  endpoints,
  onToggleIsolation,
  onToggleTamperProtection,
  onOpenDeployModal,
  onSimulateNewDevice,
}) => {
  const [osFilter, setOsFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredEndpoints = endpoints.filter((ep) => {
    if (osFilter !== 'all' && ep.os !== osFilter) return false;
    if (statusFilter !== 'all' && ep.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        ep.hostname.toLowerCase().includes(q) ||
        ep.user.toLowerCase().includes(q) ||
        ep.department.toLowerCase().includes(q) ||
        ep.ip.includes(q) ||
        ep.assignedPolicy.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const avgMemory = (
    endpoints.reduce((acc, ep) => acc + ep.agentMemoryMb, 0) / (endpoints.length || 1)
  ).toFixed(1);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            Endpoint Fleet & Lightweight Agents
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Rust-powered eBPF agents consuming &lt;15MB RAM with zero kernel crashes or reboots.
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            onClick={onSimulateNewDevice}
            className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-slate-600 hover:bg-slate-800 transition-colors"
            title="Simulate enrolling a new laptop into SentinelLite"
          >
            <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
            <span>Simulate Device Check-In</span>
          </button>

          <button
            onClick={onOpenDeployModal}
            className="flex items-center gap-1.5 rounded-lg bg-cyan-500 px-3.5 py-1.5 text-xs font-semibold text-slate-950 hover:bg-cyan-400 transition-colors shadow-sm"
          >
            <Plus className="h-3.5 w-3.5 stroke-[2.5]" />
            <span>Deploy Agent (MSI / Curl)</span>
          </button>
        </div>
      </div>

      {/* Fleet Stats Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4">
          <div className="text-xs text-slate-400">Total Enrolled Fleet</div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-bold text-white tabular-nums">
              {endpoints.length}
            </span>
            <span className="text-xs text-slate-400">active workstations & servers</span>
          </div>
          <div className="mt-2 text-[11px] text-emerald-400 font-medium">
            100% online & sending heartbeats
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4">
          <div className="text-xs text-slate-400">Average Agent Memory Footprint</div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-bold text-cyan-400 tabular-nums">
              {avgMemory} MB
            </span>
            <span className="text-xs text-slate-400">RAM per host</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Enterprise agents: 450MB–800MB RAM
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4">
          <div className="text-xs text-slate-400">Tamper & Ransomware Protection</div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-bold text-emerald-400 tabular-nums">
              Active
            </span>
            <span className="text-xs text-slate-400">on all hosts</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            VSS shadow copy auto-guard enabled
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by hostname, user, IP, or policy..."
            className="w-full rounded-lg border border-slate-800 bg-slate-900/80 pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* OS Filter */}
          <div className="flex items-center rounded-lg border border-slate-800 bg-slate-900/80 p-0.5 text-xs">
            {[
              { id: 'all', label: 'All OS' },
              { id: 'windows', label: 'Windows' },
              { id: 'macos', label: 'macOS' },
              { id: 'linux', label: 'Linux' },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setOsFilter(item.id)}
                className={`px-3 py-1 rounded font-medium transition-colors ${
                  osFilter === item.id
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Status Filter */}
          <div className="flex items-center rounded-lg border border-slate-800 bg-slate-900/80 p-0.5 text-xs">
            {[
              { id: 'all', label: 'All Status' },
              { id: 'protected', label: 'Protected' },
              { id: 'isolated', label: 'Isolated' },
              { id: 'warning', label: 'Alert' },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setStatusFilter(item.id)}
                className={`px-2.5 py-1 rounded font-medium transition-colors ${
                  statusFilter === item.id
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* High-Density Fleet Table */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/40 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400">
                <th className="py-3 px-4 font-medium">Hostname & Role</th>
                <th className="py-3 px-4 font-medium">User & Dept</th>
                <th className="py-3 px-4 font-medium">OS Platform</th>
                <th className="py-3 px-4 font-medium">Network (IPs)</th>
                <th className="py-3 px-4 font-medium text-right">Agent Footprint</th>
                <th className="py-3 px-4 font-medium text-center">Tamper Guard</th>
                <th className="py-3 px-4 font-medium text-right">Isolation / Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredEndpoints.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    No endpoints match the current filter criteria.
                  </td>
                </tr>
              ) : (
                filteredEndpoints.map((ep) => (
                  <tr key={ep.id} className="hover:bg-slate-900/50 transition-colors">
                    {/* Hostname */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        {ep.os === 'linux' ? (
                          <Server className="h-4 w-4 text-cyan-400 shrink-0" />
                        ) : (
                          <Laptop className="h-4 w-4 text-cyan-400 shrink-0" />
                        )}
                        <div>
                          <div className="font-semibold text-white">{ep.hostname}</div>
                          <div className="text-[11px] text-slate-400">{ep.assignedPolicy}</div>
                        </div>
                      </div>
                    </td>

                    {/* User & Dept */}
                    <td className="py-3 px-4 text-slate-300">
                      <div>{ep.user}</div>
                      <div className="text-[11px] text-slate-500">{ep.department}</div>
                    </td>

                    {/* OS Platform */}
                    <td className="py-3 px-4 text-slate-300">
                      <div className="capitalize">{ep.os}</div>
                      <div className="text-[11px] text-slate-500">{ep.osVersion}</div>
                    </td>

                    {/* Network IPs */}
                    <td className="py-3 px-4 text-slate-300 font-mono text-[11px]">
                      <div>{ep.ip}</div>
                      <div className="text-slate-500">{ep.publicIp}</div>
                    </td>

                    {/* Agent Footprint */}
                    <td className="py-3 px-4 text-right">
                      <div className="font-mono text-cyan-300 font-semibold tabular-nums">
                        {ep.agentMemoryMb} MB RAM
                      </div>
                      <div className="text-[11px] font-mono text-slate-400 tabular-nums">
                        {ep.agentCpuPercent}% CPU · {ep.agentVersion}
                      </div>
                    </td>

                    {/* Tamper Guard */}
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => onToggleTamperProtection(ep.id)}
                        className={`inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium transition-colors ${
                          ep.tamperProtection
                            ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/40'
                            : 'bg-rose-950/40 text-rose-400 border border-rose-800/40'
                        }`}
                        title="Click to toggle kernel tamper protection"
                      >
                        <Shield className="h-3 w-3" />
                        <span>{ep.tamperProtection ? 'Enforced' : 'Disabled'}</span>
                      </button>
                    </td>

                    {/* Isolation / Action */}
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onToggleIsolation(ep.id)}
                        className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-semibold transition-colors ${
                          ep.status === 'isolated'
                            ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                            : 'border border-slate-700 bg-slate-900 text-slate-300 hover:border-slate-600 hover:text-white'
                        }`}
                      >
                        {ep.status === 'isolated' ? (
                          <>
                            <Lock className="h-3 w-3" />
                            <span>Isolated</span>
                          </>
                        ) : (
                          <>
                            <Unlock className="h-3 w-3 text-slate-500" />
                            <span>Isolate</span>
                          </>
                        )}
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="border-t border-slate-800 px-4 py-3 bg-slate-950/40 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-400">
          <span>Showing {filteredEndpoints.length} of {endpoints.length} fleet endpoints</span>
          <span className="font-mono">Heartbeat interval: 10 seconds · Telemetry format: Compact Protobuf</span>
        </div>
      </div>

      {/* Engineering Deep-Dive: Why SentinelLite Agent is 97% Lighter */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/30 p-5">
        <h2 className="text-sm font-semibold text-white mb-2 flex items-center gap-2">
          <Layers className="h-4 w-4 text-cyan-400" />
          <span>Lightweight Agent Architecture: eBPF & Rust Design</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-300 pt-1">
          <div>
            <div className="font-semibold text-cyan-300 mb-1">01. Kernel eBPF Telemetry</div>
            <p className="text-slate-400 leading-relaxed">
              On Linux and modern kernels, SentinelLite executes safe sandbox verifier probes directly inside the kernel, filtering benign events before they reach user space.
            </p>
          </div>
          <div>
            <div className="font-semibold text-cyan-300 mb-1">02. Memory-Safe Rust Daemon</div>
            <p className="text-slate-400 leading-relaxed">
              Compiled to a single static binary without a heavy Node/Python/JVM runtime. Memory consumption is locked under 15MB with strict heap allocation caps.
            </p>
          </div>
          <div>
            <div className="font-semibold text-cyan-300 mb-1">03. Zero Reboot Guarantee</div>
            <p className="text-slate-400 leading-relaxed">
              Installs silently in under 5 seconds via standard MSI, PKG, or curl. Does not intercept legacy NDIS or hook SSDT, eliminating the risk of BSODs.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
