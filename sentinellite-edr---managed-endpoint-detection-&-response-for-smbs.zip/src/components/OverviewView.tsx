import React from 'react';
import { Alert, Endpoint } from '../types/edr';
import {
  ShieldAlert,
  Cpu,
  Server,
  Activity,
  ArrowRight,
  Zap,
  CheckCircle2,
  Lock,
  ChevronRight,
  TrendingDown,
  Sparkles
} from 'lucide-react';

interface OverviewViewProps {
  alerts: Alert[];
  endpoints: Endpoint[];
  onSelectAlert: (alertId: string) => void;
  onNavigateTab: (tab: string) => void;
  onIsolateEndpoint: (endpointId: string) => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  alerts,
  endpoints,
  onSelectAlert,
  onNavigateTab,
  onIsolateEndpoint,
}) => {
  const activeAlerts = alerts.filter(
    (a) => a.status === 'action_required' || a.status === 'soc_investigating'
  );
  const criticalCount = alerts.filter((a) => a.severity === 'critical').length;
  const protectedCount = endpoints.filter((e) => e.status === 'protected').length;
  const isolatedCount = endpoints.filter((e) => e.status === 'isolated').length;
  const avgMemory = (
    endpoints.reduce((acc, ep) => acc + ep.agentMemoryMb, 0) / (endpoints.length || 1)
  ).toFixed(1);
  const avgCpu = (
    endpoints.reduce((acc, ep) => acc + ep.agentCpuPercent, 0) / (endpoints.length || 1)
  ).toFixed(2);

  // Highest priority alert
  const primaryAlert = alerts.find((a) => a.status === 'action_required') || alerts[0];

  return (
    <div className="space-y-8">
      {/* Top Banner / Headline */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            SMB Security Operations Center
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Lightweight kernel telemetry · 24/7 Managed SOC human triage · Zero alert fatigue
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded-lg border border-emerald-500/20 bg-emerald-500/5 px-3 py-1.5 text-xs text-emerald-300">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span>Managed SOC Active · SLA &lt; 8m</span>
          </div>
          <button
            onClick={() => onNavigateTab('canary')}
            className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-slate-600 hover:bg-slate-800 transition-colors"
          >
            <Zap className="h-3.5 w-3.5 text-cyan-400" />
            <span>Run Canary Test</span>
          </button>
        </div>
      </div>

      {/* 4 Core Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Fleet Protection</span>
            <Server className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="font-mono text-3xl font-bold tabular-nums text-white">
              {protectedCount}
            </span>
            <span className="font-mono text-xs text-slate-400 tabular-nums">
              / {endpoints.length} endpoints
            </span>
          </div>
          <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-400">
            <span className="text-emerald-400 font-medium">{protectedCount} healthy</span>
            <span aria-hidden="true">·</span>
            <span className="text-amber-400 font-medium">{isolatedCount} isolated</span>
            <span aria-hidden="true">·</span>
            <span>100% policy match</span>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Agent Memory Footprint</span>
            <Cpu className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="font-mono text-3xl font-bold tabular-nums text-white">
              {avgMemory}
            </span>
            <span className="text-xs text-slate-400">MB RAM avg</span>
          </div>
          <div className="mt-3 flex items-center gap-1 text-xs text-emerald-400">
            <TrendingDown className="h-3.5 w-3.5" />
            <span>97% lighter than CrowdStrike (550MB)</span>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Triaged Managed Alerts</span>
            <ShieldAlert className="h-4 w-4 text-rose-400" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="font-mono text-3xl font-bold tabular-nums text-rose-400">
              {activeAlerts.length}
            </span>
            <span className="text-xs text-slate-400">active triage</span>
          </div>
          <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-400">
            <span className="text-rose-400 font-medium">{criticalCount} Critical</span>
            <span aria-hidden="true">·</span>
            <span>Zero un-triaged raw noise</span>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">SOC Human Triage SLA</span>
            <Activity className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="font-mono text-3xl font-bold tabular-nums text-emerald-400">
              4.2
            </span>
            <span className="text-xs text-slate-400">min mean response</span>
          </div>
          <div className="mt-3 text-xs text-slate-400">
            Lead Analyst: Sarah Vance, GIAC GCDA
          </div>
        </div>
      </div>

      {/* Critical Triage Callout Banner (Action Required) */}
      {primaryAlert && primaryAlert.status === 'action_required' && (
        <div className="rounded-xl border border-rose-500/30 bg-rose-950/20 p-5">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="font-semibold text-rose-400">Action Required</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono text-slate-300">{primaryAlert.id}</span>
                <span aria-hidden="true">·</span>
                <span className="text-slate-300">{primaryAlert.endpointName}</span>
                <span aria-hidden="true">·</span>
                <span className="text-slate-400">{primaryAlert.endpointUser}</span>
              </div>
              <h3 className="text-lg font-bold text-white">
                {primaryAlert.title}
              </h3>
              <p className="text-sm text-slate-300 max-w-3xl leading-relaxed">
                {primaryAlert.socSummary}
              </p>
              <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-3 text-xs text-slate-300">
                <div className="font-semibold text-cyan-400 mb-1 flex items-center gap-1.5">
                  <Sparkles className="h-3 w-3" />
                  <span>Managed SOC Analyst Finding ({primaryAlert.socAnalyst.name}):</span>
                </div>
                <p className="italic text-slate-300">{primaryAlert.socAnalyst.notes}</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row lg:flex-col gap-2 shrink-0">
              <button
                onClick={() => onIsolateEndpoint(primaryAlert.endpointId)}
                className="flex items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-rose-500 transition-colors shadow-sm"
              >
                <Lock className="h-3.5 w-3.5" />
                <span>1-Click: Isolate {primaryAlert.endpointName}</span>
              </button>

              <button
                onClick={() => onSelectAlert(primaryAlert.id)}
                className="flex items-center justify-center gap-2 rounded-lg border border-slate-700 bg-slate-900 px-4 py-2 text-xs font-medium text-slate-200 hover:border-slate-600 hover:bg-slate-800 transition-colors"
              >
                <span>Inspect Process Tree</span>
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* The Problem with Enterprise EDR for SMBs - Value Proposition Card */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 mb-4">
          <div>
            <h2 className="text-base font-semibold text-white">
              Why Enterprise EDR Fails Small & Midsize Businesses
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Built ground-up for lean IT generalists who cannot babysit 200 raw telemetry alerts per day.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('tco')}
            className="flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 font-medium"
          >
            <span>Calculate SMB ROI</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {/* Card 1 */}
          <div className="rounded-lg border border-slate-800/80 bg-slate-950/50 p-4">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Budget & Licensing
            </div>
            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex items-start gap-2 text-rose-400">
                <span className="font-bold">✕ Enterprise:</span>
                <span>$140–$190/endpoint/yr with mandatory $50,000 annual MSSP SOC minimum contract.</span>
              </div>
              <div className="flex items-start gap-2 text-emerald-400 pt-1 border-t border-slate-800/60">
                <span className="font-bold">✓ SentinelLite:</span>
                <span>$4/mo ($48/yr) per endpoint with 24/7 Managed SOC analyst triage included.</span>
              </div>
            </div>
          </div>

          {/* Card 2 */}
          <div className="rounded-lg border border-slate-800/80 bg-slate-950/50 p-4">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Agent Performance
            </div>
            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex items-start gap-2 text-rose-400">
                <span className="font-bold">✕ Enterprise:</span>
                <span>500MB+ RAM consumption, noticeable laptop battery drain, invasive kernel drivers causing blue screens.</span>
              </div>
              <div className="flex items-start gap-2 text-emerald-400 pt-1 border-t border-slate-800/60">
                <span className="font-bold">✓ SentinelLite:</span>
                <span>&lt;15MB RAM Rust daemon with eBPF probes. Zero reboots, zero blue screens, near-zero CPU.</span>
              </div>
            </div>
          </div>

          {/* Card 3 */}
          <div className="rounded-lg border border-slate-800/80 bg-slate-950/50 p-4">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Operational Triage
            </div>
            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex items-start gap-2 text-rose-400">
                <span className="font-bold">✕ Enterprise:</span>
                <span>Dozens of cryptic JSON alerts daily. Requires hiring 24/7 dedicated tier-3 analysts ($120k/yr each).</span>
              </div>
              <div className="flex items-start gap-2 text-emerald-400 pt-1 border-t border-slate-800/60">
                <span className="font-bold">✓ SentinelLite:</span>
                <span>Every alert is human-vetted by our SOC. Plain-English risk assessment with 1-click containment.</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Two Column Section: Recent Managed Alerts & Fleet Pulse */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Recent Alerts */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Active Managed Alert Queue</h3>
              <p className="text-xs text-slate-400">Vetted detections mapped to MITRE ATT&CK</p>
            </div>
            <button
              onClick={() => onNavigateTab('alerts')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium"
            >
              View All ({alerts.length})
            </button>
          </div>

          <div className="space-y-3">
            {alerts.slice(0, 4).map((alert) => (
              <div
                key={alert.id}
                onClick={() => onSelectAlert(alert.id)}
                className="group cursor-pointer rounded-lg border border-slate-800/80 bg-slate-950/40 p-3.5 hover:border-slate-700 hover:bg-slate-900/60 transition-all"
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span
                      className={`font-semibold ${
                        alert.severity === 'critical'
                          ? 'text-rose-400'
                          : alert.severity === 'high'
                          ? 'text-amber-400'
                          : 'text-cyan-400'
                      }`}
                    >
                      {alert.severity.toUpperCase()}
                    </span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="font-mono text-slate-400">{alert.techniqueId}</span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-slate-300 font-medium">{alert.endpointName}</span>
                  </div>
                  <span className="text-slate-400 text-xs">{alert.timestamp.split(' ')[1]} UTC</span>
                </div>
                <div className="mt-1 text-sm font-medium text-slate-200 group-hover:text-cyan-300 transition-colors">
                  {alert.title}
                </div>
                <div className="mt-1 text-xs text-slate-400 line-clamp-1">
                  {alert.socSummary}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Endpoint Fleet Telemetry Snapshot */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Live Endpoint Telemetry</h3>
              <p className="text-xs text-slate-400">Real-time kernel heartbeat and agent resource budget</p>
            </div>
            <button
              onClick={() => onNavigateTab('fleet')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium"
            >
              Manage Fleet ({endpoints.length})
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="pb-2.5 font-medium">Endpoint</th>
                  <th className="pb-2.5 font-medium">OS</th>
                  <th className="pb-2.5 font-medium text-right">RAM</th>
                  <th className="pb-2.5 font-medium text-right">CPU</th>
                  <th className="pb-2.5 font-medium text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {endpoints.slice(0, 5).map((ep) => (
                  <tr key={ep.id} className="hover:bg-slate-900/30 transition-colors">
                    <td className="py-2.5">
                      <div className="font-medium text-slate-200">{ep.hostname}</div>
                      <div className="text-slate-400 font-mono text-[11px]">{ep.ip}</div>
                    </td>
                    <td className="py-2.5 text-slate-300 capitalize">{ep.os}</td>
                    <td className="py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {ep.agentMemoryMb} MB
                    </td>
                    <td className="py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {ep.agentCpuPercent}%
                    </td>
                    <td className="py-2.5 text-right">
                      {ep.status === 'protected' && (
                        <span className="text-emerald-400 font-medium">Protected</span>
                      )}
                      {ep.status === 'isolated' && (
                        <span className="text-amber-400 font-medium">Isolated</span>
                      )}
                      {ep.status === 'warning' && (
                        <span className="text-rose-400 font-medium">Alert</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-400">
            <span>Average Agent RAM: <strong className="font-mono text-slate-200 tabular-nums">{avgMemory} MB</strong></span>
            <span>Total Fleet Protection: <strong className="font-mono text-emerald-400 tabular-nums">Active</strong></span>
          </div>
        </div>
      </div>
    </div>
  );
};
