import React, { useState } from 'react';
import { Alert, ProcessNode } from '../types/edr';
import {
  Search,
  Lock,
  Unlock,
  Slash,
  RotateCcw,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  Terminal,
  Globe,
  FileCode,
  User,
  MessageSquare,
  Sparkles,
  ExternalLink,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface AlertsViewProps {
  alerts: Alert[];
  selectedAlertId: string | null;
  onSelectAlert: (alertId: string) => void;
  onUpdateAlertRemediation: (
    alertId: string,
    action: 'isolated' | 'processKilled' | 'snapshotReverted' | 'iocBlocked'
  ) => void;
  onOpenSocChat: () => void;
}

export const AlertsView: React.FC<AlertsViewProps> = ({
  alerts,
  selectedAlertId,
  onSelectAlert,
  onUpdateAlertRemediation,
  onOpenSocChat,
}) => {
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredAlerts = alerts.filter((alert) => {
    if (severityFilter !== 'all' && alert.severity !== severityFilter) return false;
    if (statusFilter !== 'all' && alert.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        alert.title.toLowerCase().includes(q) ||
        alert.endpointName.toLowerCase().includes(q) ||
        alert.techniqueId.toLowerCase().includes(q) ||
        alert.techniqueName.toLowerCase().includes(q) ||
        alert.fileHash.fileName.toLowerCase().includes(q) ||
        alert.endpointUser.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const activeAlert = alerts.find((a) => a.id === selectedAlertId) || filteredAlerts[0] || alerts[0];

  const renderProcessNode = (node: ProcessNode, depth = 0) => {
    return (
      <div key={node.id} className="relative">
        <div
          className={`flex items-start gap-2.5 rounded-lg border p-2.5 transition-colors ${
            node.isMalicious
              ? 'border-rose-500/40 bg-rose-950/20 text-rose-200'
              : 'border-slate-800 bg-slate-900/60 text-slate-300'
          }`}
          style={{ marginLeft: `${depth * 20}px` }}
        >
          <Terminal className={`h-4 w-4 shrink-0 mt-0.5 ${node.isMalicious ? 'text-rose-400' : 'text-slate-400'}`} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 text-xs">
              <span className="font-semibold text-white">{node.name}</span>
              <span className="font-mono text-slate-400 tabular-nums">PID: {node.pid}</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="text-slate-400">{node.user}</span>
              {node.isMalicious && (
                <span className="ml-auto text-rose-400 text-[11px] font-semibold">
                  [SUSPICIOUS PAYLOAD]
                </span>
              )}
            </div>
            <div className="mt-1 font-mono text-[11px] text-slate-300 break-all bg-slate-950/80 p-1.5 rounded border border-slate-800/80">
              {node.commandLine}
            </div>
          </div>
        </div>

        {node.children && node.children.length > 0 && (
          <div className="mt-2 space-y-2">
            {node.children.map((child) => renderProcessNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            Managed Detections & Alert Triage
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Human-verified threat analysis with plain-English business risk context and 1-click containment.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSocChat}
            className="flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-900 px-3.5 py-1.5 text-xs font-medium text-slate-200 hover:border-slate-600 hover:bg-slate-800 transition-colors"
          >
            <MessageSquare className="h-3.5 w-3.5 text-cyan-400" />
            <span>Ask Lead Analyst (Sarah Vance)</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by endpoint, technique (T1490), hash, user..."
            className="w-full rounded-lg border border-slate-800 bg-slate-900/80 pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
          />
        </div>

        {/* Segmented Controls for Filters */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Severity tabs */}
          <div className="flex items-center rounded-lg border border-slate-800 bg-slate-900/80 p-0.5 text-xs">
            {['all', 'critical', 'high', 'medium', 'low'].map((sev) => (
              <button
                key={sev}
                onClick={() => setSeverityFilter(sev)}
                className={`px-2.5 py-1 rounded capitalize font-medium transition-colors ${
                  severityFilter === sev
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {sev}
              </button>
            ))}
          </div>

          {/* Status tabs */}
          <div className="flex items-center rounded-lg border border-slate-800 bg-slate-900/80 p-0.5 text-xs">
            {[
              { id: 'all', label: 'All Status' },
              { id: 'action_required', label: 'Action Required' },
              { id: 'soc_investigating', label: 'Investigating' },
              { id: 'contained', label: 'Contained' },
              { id: 'resolved', label: 'Resolved' },
            ].map((st) => (
              <button
                key={st.id}
                onClick={() => setStatusFilter(st.id)}
                className={`px-2.5 py-1 rounded font-medium transition-colors ${
                  statusFilter === st.id
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Split Layout: Left alert list (40%), Right Forensics & Remediation (60%) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Alerts List Column */}
        <div className="lg:col-span-5 space-y-2.5">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>Showing {filteredAlerts.length} Managed Detections</span>
            <span>Sorted by urgency</span>
          </div>

          {filteredAlerts.length === 0 ? (
            <div className="rounded-xl border border-slate-800 bg-slate-900/30 p-8 text-center">
              <ShieldCheck className="mx-auto h-8 w-8 text-emerald-400/60" />
              <div className="mt-2 text-sm font-semibold text-white">No detections matching filters</div>
              <p className="mt-1 text-xs text-slate-400">All fleet endpoints are running normally within baseline.</p>
              <button
                onClick={() => {
                  setSeverityFilter('all');
                  setStatusFilter('all');
                  setSearchQuery('');
                }}
                className="mt-3 text-xs text-cyan-400 hover:underline"
              >
                Clear all filters
              </button>
            </div>
          ) : (
            filteredAlerts.map((alert) => {
              const isSelected = activeAlert?.id === alert.id;
              return (
                <div
                  key={alert.id}
                  onClick={() => onSelectAlert(alert.id)}
                  className={`cursor-pointer rounded-xl border p-4 transition-all ${
                    isSelected
                      ? 'border-cyan-500/60 bg-slate-900 shadow-sm shadow-cyan-950/20'
                      : 'border-slate-800/80 bg-slate-900/40 hover:border-slate-700 hover:bg-slate-900/70'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <span
                        className={`font-semibold uppercase ${
                          alert.severity === 'critical'
                            ? 'text-rose-400'
                            : alert.severity === 'high'
                            ? 'text-amber-400'
                            : 'text-cyan-400'
                        }`}
                      >
                        {alert.severity}
                      </span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="font-mono text-slate-400">{alert.techniqueId}</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-300 font-medium">{alert.endpointName}</span>
                    </div>
                    <span className="text-slate-400 font-mono text-[11px] tabular-nums">
                      {alert.timestamp.split(' ')[1]}
                    </span>
                  </div>

                  <div className="mt-1.5 text-sm font-semibold text-white">
                    {alert.title}
                  </div>

                  <p className="mt-1 text-xs text-slate-400 line-clamp-2 leading-relaxed">
                    {alert.socSummary}
                  </p>

                  <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-800/60 text-xs">
                    <div className="flex items-center gap-1.5 text-slate-400">
                      <User className="h-3 w-3" />
                      <span>{alert.endpointUser}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {alert.status === 'action_required' && (
                        <span className="text-rose-400 font-medium">Action Required</span>
                      )}
                      {alert.status === 'soc_investigating' && (
                        <span className="text-amber-400 font-medium">Investigating</span>
                      )}
                      {alert.status === 'contained' && (
                        <span className="text-cyan-400 font-medium">Contained</span>
                      )}
                      {alert.status === 'resolved' && (
                        <span className="text-emerald-400 font-medium">Resolved</span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Alert Details & Forensics Column */}
        {activeAlert && (
          <div className="lg:col-span-7 space-y-5 rounded-xl border border-slate-800 bg-slate-900/60 p-6">
            {/* Header info */}
            <div>
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <span
                    className={`font-semibold uppercase tracking-wider ${
                      activeAlert.severity === 'critical'
                        ? 'text-rose-400'
                        : activeAlert.severity === 'high'
                        ? 'text-amber-400'
                        : 'text-cyan-400'
                    }`}
                  >
                    {activeAlert.severity} Severity
                  </span>
                  <span aria-hidden="true" className="text-slate-600">·</span>
                  <span className="font-mono text-slate-300">{activeAlert.id}</span>
                  <span aria-hidden="true" className="text-slate-600">·</span>
                  <span className="text-slate-300 font-mono tabular-nums">{activeAlert.timestamp}</span>
                </div>
                <div className="text-slate-400 text-xs">
                  Target: <strong className="text-slate-200">{activeAlert.endpointName}</strong> ({activeAlert.endpointIp})
                </div>
              </div>

              <h2 className="mt-2 text-lg font-bold text-white leading-tight">
                {activeAlert.title}
              </h2>
            </div>

            {/* Managed SOC Human Assessment Card (Plain English) */}
            <div className="rounded-xl border border-cyan-500/20 bg-cyan-950/10 p-4">
              <div className="flex items-center justify-between pb-2 border-b border-cyan-900/30">
                <div className="flex items-center gap-2">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-cyan-500/20 text-cyan-300 font-semibold text-xs border border-cyan-500/40">
                    {activeAlert.socAnalyst.avatar}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">
                      {activeAlert.socAnalyst.name}
                    </div>
                    <div className="text-[11px] text-cyan-400">
                      {activeAlert.socAnalyst.role} · Verified {activeAlert.socAnalyst.verifiedAt}
                    </div>
                  </div>
                </div>
                <button
                  onClick={onOpenSocChat}
                  className="flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 font-medium"
                >
                  <MessageSquare className="h-3.5 w-3.5" />
                  <span>Reply</span>
                </button>
              </div>

              <div className="mt-3 space-y-2 text-xs text-slate-200 leading-relaxed">
                <div>
                  <strong className="text-cyan-300">Executive Summary:</strong> {activeAlert.socSummary}
                </div>
                <div>
                  <strong className="text-amber-300">SMB Business Impact:</strong> {activeAlert.businessRisk}
                </div>
                <div className="rounded-lg bg-slate-950/60 p-2.5 border border-slate-800/80 italic text-slate-300">
                  &ldquo;{activeAlert.socAnalyst.notes}&rdquo;
                </div>
              </div>
            </div>

            {/* 1-Click Managed Instant Remediation Action Bar */}
            <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-4">
              <div className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2.5 flex items-center justify-between">
                <span>1-Click Managed Remediation Actions</span>
                <span className="text-[11px] text-slate-400 normal-case">
                  Changes propagate to agent in &lt;1.2 seconds
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {/* Action 1: Isolate Endpoint */}
                <button
                  onClick={() =>
                    onUpdateAlertRemediation(activeAlert.id, 'isolated')
                  }
                  className={`flex items-center justify-between rounded-lg border p-2.5 text-xs font-medium transition-all ${
                    activeAlert.remediationStatus.isolated
                      ? 'border-amber-500/40 bg-amber-950/30 text-amber-300'
                      : 'border-slate-700 bg-slate-900 text-slate-200 hover:border-slate-600 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {activeAlert.remediationStatus.isolated ? (
                      <Lock className="h-4 w-4 text-amber-400" />
                    ) : (
                      <Unlock className="h-4 w-4 text-slate-400" />
                    )}
                    <div className="text-left">
                      <div>{activeAlert.remediationStatus.isolated ? 'Endpoint Isolated' : 'Isolate Endpoint'}</div>
                      <div className="text-[10px] text-slate-400">Sever network except agent C2</div>
                    </div>
                  </div>
                  {activeAlert.remediationStatus.isolated && (
                    <CheckCircle2 className="h-4 w-4 text-amber-400" />
                  )}
                </button>

                {/* Action 2: Kill Process Tree */}
                <button
                  onClick={() =>
                    onUpdateAlertRemediation(activeAlert.id, 'processKilled')
                  }
                  className={`flex items-center justify-between rounded-lg border p-2.5 text-xs font-medium transition-all ${
                    activeAlert.remediationStatus.processKilled
                      ? 'border-emerald-500/40 bg-emerald-950/30 text-emerald-300'
                      : 'border-slate-700 bg-slate-900 text-slate-200 hover:border-slate-600 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Slash className="h-4 w-4 text-rose-400" />
                    <div className="text-left">
                      <div>{activeAlert.remediationStatus.processKilled ? 'Process Tree Terminated' : 'Kill Process Tree'}</div>
                      <div className="text-[10px] text-slate-400">Halt parent & child PIDs</div>
                    </div>
                  </div>
                  {activeAlert.remediationStatus.processKilled && (
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  )}
                </button>

                {/* Action 3: Revert via Local Snapshot */}
                <button
                  onClick={() =>
                    onUpdateAlertRemediation(activeAlert.id, 'snapshotReverted')
                  }
                  className={`flex items-center justify-between rounded-lg border p-2.5 text-xs font-medium transition-all ${
                    activeAlert.remediationStatus.snapshotReverted
                      ? 'border-emerald-500/40 bg-emerald-950/30 text-emerald-300'
                      : 'border-slate-700 bg-slate-900 text-slate-200 hover:border-slate-600 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <RotateCcw className="h-4 w-4 text-cyan-400" />
                    <div className="text-left">
                      <div>{activeAlert.remediationStatus.snapshotReverted ? 'Snapshot Restored' : 'Revert File Modifications'}</div>
                      <div className="text-[10px] text-slate-400">Rollback to pre-attack VSS state</div>
                    </div>
                  </div>
                  {activeAlert.remediationStatus.snapshotReverted && (
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  )}
                </button>

                {/* Action 4: Fleet-Wide Block IoC */}
                <button
                  onClick={() =>
                    onUpdateAlertRemediation(activeAlert.id, 'iocBlocked')
                  }
                  className={`flex items-center justify-between rounded-lg border p-2.5 text-xs font-medium transition-all ${
                    activeAlert.remediationStatus.iocBlocked
                      ? 'border-emerald-500/40 bg-emerald-950/30 text-emerald-300'
                      : 'border-slate-700 bg-slate-900 text-slate-200 hover:border-slate-600 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Globe className="h-4 w-4 text-purple-400" />
                    <div className="text-left">
                      <div>{activeAlert.remediationStatus.iocBlocked ? 'IoC Blocked on All Endpoints' : 'Fleet-Wide Block IoC'}</div>
                      <div className="text-[10px] text-slate-400">Broadcast hash & IP to entire fleet</div>
                    </div>
                  </div>
                  {activeAlert.remediationStatus.iocBlocked && (
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  )}
                </button>
              </div>
            </div>

            {/* Process Lineage Tree Forensics */}
            <div className="rounded-xl border border-slate-800 bg-slate-950/50 p-4 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200 uppercase tracking-wider">
                  Process Execution Lineage
                </span>
                <span className="text-slate-400">Kernel telemetry recorded by eBPF agent</span>
              </div>

              <div className="space-y-2">
                {renderProcessNode(activeAlert.processTree)}
              </div>
            </div>

            {/* Artifacts & IoC Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              {/* File Hash */}
              <div className="rounded-lg border border-slate-800 bg-slate-950/50 p-3.5 space-y-2">
                <div className="flex items-center gap-1.5 font-semibold text-slate-200">
                  <FileCode className="h-3.5 w-3.5 text-cyan-400" />
                  <span>Payload Hash & File</span>
                </div>
                <div className="space-y-1 text-slate-400">
                  <div>
                    <span className="text-slate-500">File Name:</span>{' '}
                    <strong className="text-slate-200">{activeAlert.fileHash.fileName}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500">File Path:</span>{' '}
                    <span className="font-mono text-[11px] text-slate-300 break-all">{activeAlert.fileHash.filePath}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">SHA-256:</span>{' '}
                    <span className="font-mono text-[11px] text-slate-300 break-all">{activeAlert.fileHash.sha256}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">VirusTotal Detection:</span>{' '}
                    <span className="font-mono text-rose-400 font-semibold">{activeAlert.fileHash.vtDetections}</span>
                  </div>
                </div>
              </div>

              {/* Network Connections */}
              <div className="rounded-lg border border-slate-800 bg-slate-950/50 p-3.5 space-y-2">
                <div className="flex items-center gap-1.5 font-semibold text-slate-200">
                  <Globe className="h-3.5 w-3.5 text-cyan-400" />
                  <span>Network C2 Telemetry</span>
                </div>
                {activeAlert.networkConnections.length > 0 ? (
                  activeAlert.networkConnections.map((conn, idx) => (
                    <div key={idx} className="space-y-1 text-slate-400">
                      <div>
                        <span className="text-slate-500">Destination:</span>{' '}
                        <strong className="font-mono text-slate-200">{conn.destinationIp}:{conn.destinationPort}</strong> ({conn.protocol})
                      </div>
                      <div>
                        <span className="text-slate-500">Country:</span>{' '}
                        <span className="text-slate-200">{conn.destinationCountry}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">Reputation:</span>{' '}
                        <span className="text-rose-400 uppercase font-semibold text-[11px]">{conn.reputation}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-slate-500 italic py-2">
                    No anomalous outbound network connections detected for this event.
                  </div>
                )}
              </div>
            </div>

            {/* MITRE ATT&CK Matrix Card */}
            <div className="rounded-lg border border-slate-800/80 bg-slate-950/40 p-3 text-xs flex items-center justify-between">
              <div>
                <span className="text-slate-400">MITRE ATT&CK Mapping:</span>{' '}
                <strong className="text-slate-200 font-mono">{activeAlert.techniqueId}</strong>{' '}
                <span className="text-slate-300">({activeAlert.techniqueName})</span> ·{' '}
                <span className="text-cyan-400">{activeAlert.tactic} Tactic</span>
              </div>
              <a
                href={`https://attack.mitre.org/techniques/${activeAlert.techniqueId.replace('.', '/')}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 text-slate-400 hover:text-white transition-colors"
              >
                <span>Docs</span>
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
