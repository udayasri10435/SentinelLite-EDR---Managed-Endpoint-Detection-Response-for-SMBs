import React, { useState } from 'react';
import { CanaryTest, Endpoint } from '../types/edr';
import {
  Zap,
  Play,
  CheckCircle2,
  AlertTriangle,
  Terminal,
  Shield,
  Layers,
  ArrowRight,
  RefreshCw
} from 'lucide-react';

interface AttackSimulatorViewProps {
  canaryTests: CanaryTest[];
  endpoints: Endpoint[];
  onExecuteCanaryTest: (test: CanaryTest, endpointId: string) => void;
  onNavigateToAlerts: () => void;
}

export const AttackSimulatorView: React.FC<AttackSimulatorViewProps> = ({
  canaryTests,
  endpoints,
  onExecuteCanaryTest,
  onNavigateToAlerts,
}) => {
  const [selectedTestId, setSelectedTestId] = useState<string>(canaryTests[0].id);
  const [selectedEndpointId, setSelectedEndpointId] = useState<string>(endpoints[0]?.id || '');
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);
  const [testCompleted, setTestCompleted] = useState<boolean>(false);

  const selectedTest = canaryTests.find((t) => t.id === selectedTestId) || canaryTests[0];
  const selectedEndpoint = endpoints.find((e) => e.id === selectedEndpointId) || endpoints[0];

  const handleRunSimulation = () => {
    if (!selectedTest || !selectedEndpoint) return;

    setIsRunning(true);
    setTestCompleted(false);
    setTerminalLogs([
      `[${new Date().toISOString().substring(11, 19)}] Initializing Atomic Canary Probe on ${selectedEndpoint.hostname}...`,
      `[${new Date().toISOString().substring(11, 19)}] Technique: ${selectedTest.mitreRef} (${selectedTest.name})`,
      `[${new Date().toISOString().substring(11, 19)}] Dispatching benign simulation probe through kernel eBPF filter...`,
    ]);

    setTimeout(() => {
      setTerminalLogs((prev) => [
        ...prev,
        `[${new Date().toISOString().substring(11, 19)}] Command dispatched: ${selectedTest.simulatedCommand}`,
        `[${new Date().toISOString().substring(11, 19)}] [KERNEL INTERCEPT] SentinelLite eBPF driver caught process initiation within 0.4ms.`,
      ]);
    }, 600);

    setTimeout(() => {
      setTerminalLogs((prev) => [
        ...prev,
        `[${new Date().toISOString().substring(11, 19)}] [HEURISTIC MATCH] Behavior matches ransomware/LOLBin threat signature.`,
        `[${new Date().toISOString().substring(11, 19)}] [CONTAINMENT] Process execution paused. Token verified safe. Telemetry forwarded to Managed SOC.`,
        `[${new Date().toISOString().substring(11, 19)}] [SUCCESS] Managed Alert generated with verified analyst response.`,
      ]);
      setIsRunning(false);
      setTestCompleted(true);
      onExecuteCanaryTest(selectedTest, selectedEndpoint.id);
    }, 1400);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            Attack Simulator & EDR Canary Sandbox
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Verify detection efficacy without risking production data. Run safe atomic MITRE ATT&CK probes on live endpoints.
          </p>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-900/80 px-3.5 py-1.5 text-xs text-slate-400">
          Safety: <strong className="text-emerald-400">100% Non-Destructive In-Memory Probes</strong>
        </div>
      </div>

      {/* Main Testing Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Test Selection (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-1">
            Select Canary Test Scenario
          </div>

          <div className="space-y-2.5">
            {canaryTests.map((test) => {
              const isSelected = test.id === selectedTestId;
              return (
                <div
                  key={test.id}
                  onClick={() => {
                    setSelectedTestId(test.id);
                    setTestCompleted(false);
                    setTerminalLogs([]);
                  }}
                  className={`cursor-pointer rounded-xl border p-4 transition-all ${
                    isSelected
                      ? 'border-cyan-500/60 bg-slate-900 shadow-sm shadow-cyan-950/20'
                      : 'border-slate-800 bg-slate-900/40 hover:border-slate-700 hover:bg-slate-900/70'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono text-cyan-400 font-semibold">{test.mitreRef}</span>
                    <span className="text-slate-400">{test.tactic}</span>
                  </div>
                  <h3 className="mt-1.5 text-sm font-semibold text-white">
                    {test.name}
                  </h3>
                  <p className="mt-1 text-xs text-slate-400 line-clamp-2 leading-relaxed">
                    {test.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Execution Console & Terminal (7 cols) */}
        <div className="lg:col-span-7 space-y-5 rounded-xl border border-slate-800 bg-slate-900/60 p-6">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-cyan-400 font-semibold">{selectedTest.mitreRef}</span>
              <span className="text-xs text-slate-400">{selectedTest.tactic}</span>
            </div>
            <h2 className="mt-1 text-lg font-bold text-white">
              {selectedTest.name}
            </h2>
            <p className="mt-1.5 text-xs text-slate-300 leading-relaxed">
              {selectedTest.description}
            </p>
          </div>

          {/* Target Endpoint Selector */}
          <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-3.5 space-y-2">
            <label className="text-xs font-semibold text-slate-300 block">
              Target Test Endpoint:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {endpoints.slice(0, 4).map((ep) => (
                <button
                  key={ep.id}
                  onClick={() => setSelectedEndpointId(ep.id)}
                  className={`flex items-center justify-between rounded-lg border p-2 text-xs transition-colors ${
                    selectedEndpointId === ep.id
                      ? 'border-cyan-500/60 bg-cyan-950/20 text-white'
                      : 'border-slate-800 bg-slate-900 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="text-left">
                    <div className="font-semibold">{ep.hostname}</div>
                    <div className="text-[11px] text-slate-400 font-mono">{ep.ip}</div>
                  </div>
                  <span className="capitalize text-[11px] text-slate-400">{ep.os}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Test Command Preview */}
          <div className="rounded-lg border border-slate-800 bg-slate-950/90 p-3.5 space-y-1.5">
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>Simulated In-Memory Command:</span>
              <span className="text-emerald-400 normal-case">Benign Sandbox Flag Attached</span>
            </div>
            <div className="font-mono text-xs text-amber-300 bg-slate-900/90 p-2 rounded border border-slate-800 break-all">
              {selectedTest.simulatedCommand}
            </div>
            <div className="text-[11px] text-slate-400 pt-1">
              <strong>Expected EDR Response:</strong> {selectedTest.expectedDetection}
            </div>
          </div>

          {/* Run Action */}
          <div className="flex items-center gap-3">
            <button
              onClick={handleRunSimulation}
              disabled={isRunning}
              className={`flex items-center gap-2 rounded-lg px-5 py-2.5 text-xs font-semibold transition-all shadow-sm ${
                isRunning
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400 shadow-cyan-500/20'
              }`}
            >
              {isRunning ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin text-cyan-400" />
                  <span>Executing Kernel Probe...</span>
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 fill-slate-950" />
                  <span>Execute Canary Test on {selectedEndpoint.hostname}</span>
                </>
              )}
            </button>

            {testCompleted && (
              <button
                onClick={onNavigateToAlerts}
                className="flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 font-medium"
              >
                <span>View Generated Detection in Alerts</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          {/* Simulated Terminal Log Output */}
          {terminalLogs.length > 0 && (
            <div className="rounded-lg border border-slate-800 bg-slate-950 p-4 font-mono text-xs space-y-1">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2 mb-2 text-slate-500 text-[11px]">
                <div className="flex items-center gap-2">
                  <Terminal className="h-3.5 w-3.5 text-cyan-400" />
                  <span>Live Agent eBPF Telemetry Pipe</span>
                </div>
                <span>host: {selectedEndpoint.hostname}</span>
              </div>
              {terminalLogs.map((log, i) => (
                <div
                  key={i}
                  className={`${
                    log.includes('[SUCCESS]')
                      ? 'text-emerald-400 font-semibold'
                      : log.includes('[KERNEL INTERCEPT]')
                      ? 'text-cyan-300 font-medium'
                      : log.includes('[HEURISTIC MATCH]')
                      ? 'text-amber-300'
                      : 'text-slate-300'
                  }`}
                >
                  {log}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
